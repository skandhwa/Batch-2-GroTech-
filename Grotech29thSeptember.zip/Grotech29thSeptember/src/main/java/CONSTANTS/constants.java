package CONSTANTS;

public class constants {
	
	public static final String URLPATH="C:\\Users\\saura\\OneDrive\\Documents\\TestData2607.xlsx";
	
	

}
