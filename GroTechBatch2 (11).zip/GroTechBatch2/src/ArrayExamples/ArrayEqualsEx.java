package ArrayExamples;

import java.util.Arrays;

public class ArrayEqualsEx {

	public static void main(String[] args) {
		int a[]= {22,12,45,67};
		int b[]= {22,12,45,67,78};
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println(flag);

	}

}
