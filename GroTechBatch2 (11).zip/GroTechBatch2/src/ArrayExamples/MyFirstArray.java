package ArrayExamples;

public class MyFirstArray {

	public static void main(String[] args) {
		
		int a[]=new int[5];
		a[0]=10;
		a[1]=20;
		a[2]=40;
		a[3]=50;
		a[4]=100;
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		
		
		
		

	}

}
