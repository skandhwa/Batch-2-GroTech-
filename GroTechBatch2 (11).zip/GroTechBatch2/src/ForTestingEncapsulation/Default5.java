package ForTestingEncapsulation;
import Batch2GroTech.*;

public class Default5 extends TestNewDefault {

	public static void main(String[] args) {
		
		Default5 obj=new Default5();
		obj.display();
		

	}

}
