package ForTestingEncapsulation;

import Batch2GroTech.Default7;

public class Default9 extends Default7 {

	public static void main(String[] args) 
	{
		Default9 obj1=new Default9();
		
		obj1.display();

	}

}
