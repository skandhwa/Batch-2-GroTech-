package Batch2GroTech;

public class Constructorex1 {
	
	Constructorex1()
	{
		System.out.println("This is the first example");
	}
	
	

	public static void main(String[] args) {
		
		Constructorex1 obj=new Constructorex1();
		
		

	}

}
