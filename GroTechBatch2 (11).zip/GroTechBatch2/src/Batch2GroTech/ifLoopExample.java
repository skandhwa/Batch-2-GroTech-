package Batch2GroTech;

public class ifLoopExample {

	public static void main(String[] args) {
		
		int a=50;
		int b=10;
		if(a<b)///if(condition)
		{
			System.out.println(" I am correct");
		}
		else
		{
			System.out.println("I am not correct");
		}

	}

}
