package Batch2GroTech;




public class TestNewDefault {
	
	public void display()
	{
		System.out.println("Hello 0208");
	}
	

	public static void main(String[] args) {
		
		TestNewDefault obj=new TestNewDefault();
		obj.display();

	}

}
