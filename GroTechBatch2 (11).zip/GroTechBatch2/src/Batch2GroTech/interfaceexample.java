package Batch2GroTech;

interface printable
{
	 void print();
}

class A8 implements printable
{
	public void print() {
		System.out.println("Hello");
		
	}
	
}
public class interfaceexample {

	public static void main(String[] args) {
		
		printable obj2=new A8();
		
		//A8 obj=new A8();
		obj2.print();
		

	}

}
