package Batch2GroTech;

public class Student2 {
	
	int id;
	String name;
	float fee;
	
	Student2(int i,String n,float f)
	{
		id=i;//name of instance should on LHS
		name=n;
		fee=f;
	}
	
	void display()
	{
		System.out.println(id+" "+name+" "+fee);
	}
	
	public static void main(String[] args) {
		
		Student2 obj=new Student2(123,"Manish",2300.5f);
		Student2 obj1=new Student2(223,"Harish",5300.5f);
		obj.display();
		obj1.display();
		

	}

}
