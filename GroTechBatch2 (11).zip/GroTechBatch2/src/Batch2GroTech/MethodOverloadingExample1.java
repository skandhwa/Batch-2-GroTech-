package Batch2GroTech;

public class MethodOverloadingExample1 {
	
	static int add(int a,int b)
	{
		return a+b;
	}
	
	static float add(int c,float e)
	{
		return c+e;
	}
	
	

	public static void main(String[] args) {
		
	System.out.println(MethodOverloadingExample1.add(5, 9));	
		
	System.out.println	(MethodOverloadingExample1.add(5, 23));
	
	add(5,9);
		

	}

}
