package Batch2GroTech;

class Calculate2
{
	 static int cube(int x,int y)
	{
		return x*x*x*y;
		
	}
}





public class staticmethodexample2 {

	public static void main(String[] args) {
		
	System.out.println(Calculate2.cube(5,6));	
		

	}

}
