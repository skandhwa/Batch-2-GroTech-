//package Batch2GroTech;
//
//class Bike10
//{
//	final int speedlimit=90;
//	void run()
//	{
//		speedlimit=400;
//	}
//	
//}
//
//
//public class finalkeywordEx {
//
//	public static void main(String[] args) {
//		
//		Bike10 obj=new Bike10();
//		obj.run();
//		
//
//	}
//
//}
