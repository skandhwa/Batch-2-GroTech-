package Batch2GroTech;

public class MethodOverloadingsecond {
	
	
	public static void main(String args)
	{
		System.out.println("hello");
	}

	public static void main(String[] args) {
		
		
		main("test");
		System.out.println("I am Hello");
		
	}

}
