//package Batch2GroTech;
//
//abstract class BG
//{
//	void run()
//	{
//		System.out.println("i am concrete method");
//	}
//	
//	abstract void display();
//	
//	abstract void run2();
//	
//	void run3()
//	{
//		System.out.println("hello");
//	}
//	
//	void run4()
//	{
//		System.out.println("hello I am new ");
//	}
//	
//	
//}
//
//class BH
//{
//	void display() {
//		System.out.println("I am display method");
//		
//	}
//	
//}
//public class AbstractClassImplementation {
//
//	public static void main(String[] args) {
//		
//		BH obj=new BH();
//		
//		//BH obj=new BH();
//		obj.display();
//		obj.run();
//		
//		
//
//	}
//
//}
