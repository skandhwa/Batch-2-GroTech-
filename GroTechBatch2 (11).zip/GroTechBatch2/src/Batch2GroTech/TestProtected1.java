package Batch2GroTech;

public class CF
{
	protected void msg()
	{
		System.out.println("Hello");
	}
}



public class TestProtected1 {

	public static void main(String[] args) {
		
		CF obj=new CF();
		obj.msg();
		

	}

}
