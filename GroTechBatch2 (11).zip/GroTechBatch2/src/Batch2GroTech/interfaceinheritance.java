package Batch2GroTech;

interface printable6
{
	void print();
	
	
}

interface show extends printable6
{
	void show();
}

class TestInterface5 implements show {
	
	public void print()
	{
		System.out.println("I am print method");
	}
	
	public void show()
	{
		System.out.println("I am show method");
	}
	
	
}
public class interfaceinheritance {

	public static void main(String[] args) {
		
		show ref=new TestInterface5();
		ref.show();
		ref.print();
		

	}

}
