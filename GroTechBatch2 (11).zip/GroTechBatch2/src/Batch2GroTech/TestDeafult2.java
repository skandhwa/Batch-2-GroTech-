package Batch2GroTech;

public class TestDeafult2 {

	public static void main(String[] args) {
	
		BZ obj=new BZ();
		obj.display();

	}

}
