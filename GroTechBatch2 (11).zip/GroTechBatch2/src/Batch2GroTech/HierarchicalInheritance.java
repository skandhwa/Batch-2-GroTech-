package Batch2GroTech;

class BA
{
	void display()
	{
		System.out.println("I am display of BA");
	}
}

class CA extends BA
{
	void display1()
	{
		System.out.println("I am display of CA");
	}
}

class CB extends BA
{
	void display2()
	{
		System.out.println("I am display of CB");
	}
	
}
public class HierarchicalInheritance {

	public static void main(String[] args) {
		CB obj=new CB();
		obj.display();
		obj.display2();
	//	obj.display1();
		
		
		

	}

}
