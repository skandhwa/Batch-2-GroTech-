package Batch2GroTech;

public class UnaryDetail {
	
	 

	public static void main(String[] args) {
		
		
//		int a=3;//5//6
//		int b=2;//3///2
//
//        int c= --a + b++ - a++ + --b - a++ + --b + a++ + b++ - a++ + b++;
//        
//        /// 2+2-2+2-3+1+4+1-5+2
//        System.out.println(c);
        
        
		int x = 5;//
	     int y = 6;//
      
        x++;//5/6/7
        y++;//6/7/6
        System.out.println(x);
        System.out.println(y);
        int z =  ++x + --y + x++ + ++y - ++x + y++;
        
       

	}

}
