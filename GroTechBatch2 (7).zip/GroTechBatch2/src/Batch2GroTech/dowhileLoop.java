package Batch2GroTech;

public class dowhileLoop {

	public static void main(String[] args) {
		
		int i=500;///initialization
		
		do
		{
			System.out.println(i);//500
			++i;//501
		}
		while(i<=10);//condition checking///501<=10
		

	}

}
