package Batch2GroTech;

public class LogicalOperator {

	public static void main(String[] args) {
		
		int a=12;
		int b= 19;
		
		int c=21;
		
		a/=2;///   a=a/2
		System.out.println(a);
		
		b*=3;///   b=b*3
		System.out.println(b);
		
		
		if(a>b || a<c || b<c)//15>17 ,,, 15<21
		{
			System.out.println("I am correct");
		}
		
		else
			
		{
			System.out.println("I am false");
		}
		

	}

}
