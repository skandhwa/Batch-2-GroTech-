package Batch2GroTech;

class ABC
{
	public void display()
	{
		System.out.println("This is another class");
	}
	
	public int sum(int a,int b)
	{
		return a+b;
	}
	
	
	
}
public class MethodExample {

	public static void main(String[] args) {
		
		ABC obj=new ABC();
		obj.display();
		
		
	System.out.println("The Sum is   "+obj.sum(5, 6));	
		
		
		

	}

}
