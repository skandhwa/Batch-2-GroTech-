package Batch2GroTech;

public class DataTypeExamples {

	public static void main(String[] args) {
		
		boolean x=false;
		

	}

}
