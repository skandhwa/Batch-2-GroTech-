package GrotechBatch2Selenium;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import net.sourceforge.tess4j.Tesseract;

public class Tess4jExample {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("");
		WebElement barcode=driver.findElement(By.xpath(""));
		File imagefile=WebElementExtender.captureElementPicture(barcode);
		Tesseract obj=new Tesseract();
	String text=	obj.doOCR(imagefile);
	
	
		
		
		

	}

}
