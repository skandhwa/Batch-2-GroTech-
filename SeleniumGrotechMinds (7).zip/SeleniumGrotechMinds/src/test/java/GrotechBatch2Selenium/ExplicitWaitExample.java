package GrotechBatch2Selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitWaitExample {

	public static void main(String[] args) {
	
	//    	
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		
		WebElement Country=new WebDriverWait(driver,Duration.ofSeconds(10))
	    .until(ExpectedConditions.
elementToBeClickable(By.xpath("(//span[@class='select2-selection select2-selection--single'])[1]")));
		

	}

}
