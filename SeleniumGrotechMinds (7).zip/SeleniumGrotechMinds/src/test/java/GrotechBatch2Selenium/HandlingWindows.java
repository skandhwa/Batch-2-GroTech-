package GrotechBatch2Selenium;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindows {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String WindowId=	driver.getWindowHandle();
	System.out.println("The Window Handle value is "+WindowId);
	
	driver.findElement(By.xpath("(//button[@class='btn btn-info'])[1]")).click();
	
      Set<String>WindowIDS=	driver.getWindowHandles();
      
      for(String x:WindowIDS)
      {
    	  System.out.println("The Window Handles values are "+x);
      }

      Iterator<String> I1=WindowIDS.iterator();
      while(I1.hasNext())
      {
    	  String childwindow=I1.next();
    	  if(!WindowId.equals(childwindow))
    	  {
    		  driver.switchTo().window(childwindow);
    		String title=  driver.getTitle();
    		System.out.println(title);
    		driver.close();
    		  
    	  }
    	  
      }
      
      
      
      driver.switchTo().window(WindowId);
 String PageTitle=     driver.getTitle();
 System.out.println(PageTitle);
      
      

	
		
		

	}

}
