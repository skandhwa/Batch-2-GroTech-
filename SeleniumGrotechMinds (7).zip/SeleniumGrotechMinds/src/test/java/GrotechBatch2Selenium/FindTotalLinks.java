package GrotechBatch2Selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FindTotalLinks {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		
	List<WebElement> ele=	driver.findElements(By.tagName("a"));
	int x=ele.size();
	System.out.println(x);
	
	for(WebElement y:ele)
	{
		System.out.println(y.getText());
	}
		

	}

}
