package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgExample2 {
	
	@Test(priority=0)
	public void Fdisplay()
	{
		System.out.println("Hello I am Fpriority 0 method");//1
	}
	@Test(priority=-5)
	public void Edisplay1()
	{
		System.out.println("Hello I am priority -5 method");//2
	}
	@Test(priority='A')
	public void Ddisplay2()
	{
		System.out.println("Hello I am priority A(cpital) method");//3
	}
	@Test
	public void Cdisplay3()
	{
		System.out.println("Hello I am priority default method");//4
	}
	@Test(priority='B')
	public void Bdisplay4()
	{
		System.out.println("Hello I am priority 'B' method");//5
	}
	
	@Test(priority=5)
	public void Adisplay()
	{
		System.out.println("Hello I am priority 5 method");//6
	}
	
	
	

}
