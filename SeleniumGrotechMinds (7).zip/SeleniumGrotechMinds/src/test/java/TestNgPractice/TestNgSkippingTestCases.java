package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgSkippingTestCases {
	
	
	@Test
	public void Testdisplay()
	{
		System.out.println("hello");
	}
	
	@Test(enabled=false)
	public void msg()
	{
		System.out.println("hello I am msg");
	}
	

}
