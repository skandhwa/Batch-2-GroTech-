package TestNgPractice;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class TestNgExample1 {
	
	
	
	@Test
	public void display()
	{
		System.out.println("I am test annotation");//1
	}
	@BeforeSuite
	public void display1()
	{
		System.out.println("I am before suite");//2
	}
	
	@BeforeMethod
	public void display2()
	{
		System.out.println("I am before method");//3
	}
	
	@AfterMethod
	public void display3()
	{
		System.out.println("I am after method");//4
	}
	
	@AfterSuite
	public void display4()
	{
		System.out.println("I am after suite");//5
	}
	
	

}
