package Batch2GroTech;

class Student4
{
	int roll;
	String name;
	float fee;
	
	Student4(int roll,String name,float fee)
	{
		this.roll=roll;
		this.name=name;
		this.fee=fee;
		
	}
	
	void display()
	{
		System.out.println(roll+ "  "+name+" "+fee);
	}
	
}
public class ThisKeywordExample {

	public static void main(String[] args) {
		
		Student4 obj=new Student4(23,"Manish",4500.5f);
		obj.display();
		Student4 obj1=new Student4(33,"Ramesh",6500.5f);
		obj1.display();
		

	}

}
