package Batch2GroTech;

class Bank
{
	int getRateofIntrest(int Q1,int Q2)
	{
		return Q1+Q2;
	}
	
	void display()
	{
		System.out.println("hello");
	}
	
	
}

class SBI extends Bank
{
	int getRateofIntrest(int Q1,int Q2)
	{
		return Q1+Q2;
		
		
	}
	
	
}

class UBI extends Bank
{
	int getRateofIntrest(int Q1,int Q2)
	{
		return Q1+Q2;
	}
}
public class MethodOverridngRealtime {

	public static void main(String[] args) {
		
		UBI obj=new UBI();
	System.out.println(obj.getRateofIntrest(3,4));	
	
	obj.display();
		
		SBI obj1=new SBI();
		System.out.println(obj1.getRateofIntrest(4,4));	
		

	}

}
