package Batch2GroTech;

abstract class Shape{
	
	abstract void draw();
}

class Rectangle extends Shape
{	
	void draw()
	{
		System.out.println("Drawing rectangle");
		
	}
	
}

class Circle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Circle");
		
	}
	
}
public class abstractrealtime {

	public static void main(String[] args) {
		
		Shape obj=new Rectangle();
		obj.draw();
		Shape obj1=new Circle();
		obj1.draw();

	}

}
