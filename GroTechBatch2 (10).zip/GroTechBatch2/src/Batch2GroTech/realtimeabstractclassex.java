package Batch2GroTech;

abstract class Shape2
{
	abstract void draw();
}



public class realtimeabstractclassex {

	public static void main(String[] args) {
		

	}

}
