package Batch2GroTech;

interface Printable5
{
	void print();
}

interface Showable5 extends Printable5
{
	void show();
}

class A11 implements Printable5,Showable5
{
	public void print()
	{
		System.out.println("I am print method");
	}
	
	public void show()
	{
		System.out.println("I am show method");
	}
}

public class MultipleInheritanceUsingInterface {

	public static void main(String[] args) {
	
//		A11 obj=new A11();
//		obj.print();
//		obj.show();
		
		
		Showable5 ref=new A11();
		ref.print();
		ref.show();
		
		
		

	}

}
