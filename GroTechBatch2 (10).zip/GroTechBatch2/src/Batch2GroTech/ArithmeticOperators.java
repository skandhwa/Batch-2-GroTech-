package Batch2GroTech;

public class ArithmeticOperators {

	public static void main(String[] args) {
		
		int x=40;
		int y=13;
		int z=x+y;//Addition 
		System.out.println(z);
		
		
		int p=y-x;//Subtraction
		System.out.println(p);
		
		int s=y*x;
		System.out.println(s);
		
		int m=x/y;
		
		System.out.println(m);
		
		int k=x%y;
		System.out.println(k);

	}

}
