package Batch2GroTech;

abstract class BE
{
	void run()
	{
		System.out.println("I am run method");
	}
	
	abstract void display();
	
	final void display2()
	{
		System.out.println("Test");
	}
	
	
	

	static void display4()
	{
		
	}
	
	
	
	
}




public class AbstractClassExample {

	public static void main(String[] args) {
		

	}

}
