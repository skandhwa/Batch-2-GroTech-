package Batch2GroTech;


class Student5
{
	int roll;
	String name;
	float fee;
	String course;
	
	Student5(int roll,String name,float fee)
	{
		this.roll=roll;
		this.name=name;
		this.fee=fee;
		
	}
	
	Student5(int roll,String name,float fee,String course)
	{
		this(roll,name,fee);
		this.course=course;
		
		
	}
	
	void display()
	{
		System.out.println(roll+ "  "+name+" "+fee+"  "+course);
	}
	
}



public class RealTimeUsageofThis {

	public static void main(String[] args) {
		
		Student5 obj=new Student5(23,"Manish",4500.5f);
		obj.display();
		Student5 obj1=new Student5(33,"Ramesh",6500.5f,"Btech");
		obj1.display();
		

	}

}
