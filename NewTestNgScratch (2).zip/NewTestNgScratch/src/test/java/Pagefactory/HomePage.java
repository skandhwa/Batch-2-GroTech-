package Pagefactory;

public class HomePage 

{
	public static String getfirstname()
	{
		String firstname="//input[@id='vfb-5']";
		return firstname;
	}
	
	public static String getlastname()
	{
		String lastname="//input[@id='vfb-7']";
		return lastname;
	}
	

}
