package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingFrames2 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Frames.html");
		driver.manage().window().maximize();
		//driver.findElement(By.xpath("(//input[@type='text'])[1]")).sendKeys("Saurabh");
        driver.switchTo().frame(0);
        driver.findElement(By.xpath("(//input[@type='text'])[1]")).sendKeys("Saurabh");
      String title=  driver.getTitle();
      System.out.println(title);
      driver.switchTo().defaultContent();
      
	}

}
