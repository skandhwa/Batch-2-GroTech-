package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebElementCommands {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new FirefoxDriver();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
	WebElement ele=	driver.findElement(By.xpath("//input[@id='vfb-5']"));
	ele.sendKeys("Saurabh");
	
boolean flag=	ele.isDisplayed();
System.out.println(flag);

	
	
	
	//driver.findElement(By.xpath("//input[@id='vfb-5']")).sendKeys("Saurabh");
	
	driver.findElement(By.xpath("//input[@id='vfb-7']")).sendKeys("Kandhway");
	
	Thread.sleep(3000);
	ele.clear();
	
	driver.findElement(By.xpath("//input[@id='vfb-31-1']")).click();
	
	
	
	

	}

}
