package GrotechBatch2Selenium;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptExecutorInterfaceEx {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		driver.manage().window().maximize();
		
		
		JavascriptExecutor js=  (JavascriptExecutor)driver;
		
		js.executeScript("window.scrollBy(0,500)", "");
		

	}
 
}
