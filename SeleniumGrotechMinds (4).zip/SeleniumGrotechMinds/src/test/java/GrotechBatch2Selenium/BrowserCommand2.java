package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommand2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver dr=new ChromeDriver();
		dr.get("https://demo.automationtesting.in/Windows.html");
		
		
		
		dr.manage().window().maximize();
	String URL=	dr.getCurrentUrl();
	System.out.println(URL);
	Thread.sleep(2000);
		
		dr.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		
		Thread.sleep(2000);
		String URL2=	dr.getCurrentUrl();
		System.out.println(URL2);
		
		//dr.close();
		
		Thread.sleep(5000);
		dr.quit();
		
		
		
		

	}

}
