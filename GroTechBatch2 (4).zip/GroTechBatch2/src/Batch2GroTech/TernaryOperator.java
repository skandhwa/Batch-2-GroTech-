package Batch2GroTech;

public class TernaryOperator {

	public static void main(String[] args) {
		
		int a=200;
		int b=40;
		
		int max;
		max=(a>b)?a:b;
		System.out.println(max);

	}

}
