package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropDowns {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
	WebElement ele=	driver.findElement(By.xpath("//select[@id='continents']"));
		
	Select oselect=new Select(ele);
	//oselect.selectByIndex(3);
	oselect.selectByVisibleText("Europe");
	//oselect.selectByValue("Africa");
	
	
      
	}

}
