package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebElementCommands3 {

	public static void main(String[] args) throws InterruptedException {
	
		WebDriver driver=new FirefoxDriver();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		
		WebElement ele=driver.findElement(By.xpath("//input[@id='vfb-31-2']"));
		
//		if(ele.isEnabled()==true)
//		{
//			ele.click();
//		}
		
		
	boolean flag2=	ele.isEnabled();
	System.out.println(flag2);
	
	
WebElement ele2=	driver.findElement(By.xpath("//input[@id='vfb-20-0']"));

ele2.click();

Thread.sleep(3000);

boolean flag3=ele2.isSelected();

System.out.println(flag3);

driver.findElement(By.xpath("//input[@id='vfb-4']")).submit();

	
		

	}

}
