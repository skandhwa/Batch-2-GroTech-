package GrotechBatch2Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestNgParallelExecutionEx {

	public WebDriver driver;
	
	@Test
	public void FirefoxTestEx()
	{
		driver=new FirefoxDriver();
		
	}
	
	
	
}
