package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragNDropSeleniumExample {

	public static void main(String[] args) {
	
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/test/drag_drop.html");
		driver.manage().window().maximize();
	WebElement Src=	driver.findElement(By.xpath("(//a[@class='button button-orange'])[5]"));
	WebElement target=	driver.findElement(By.xpath("(//li[@class='placeholder'])[1]"));
	Actions act=new Actions(driver);
	act.dragAndDrop(Src, target).build().perform();
	
	
	
		
		

	}

}
