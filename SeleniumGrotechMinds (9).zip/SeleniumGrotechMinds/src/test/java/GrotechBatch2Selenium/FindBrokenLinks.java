package GrotechBatch2Selenium;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindBrokenLinks {

	public static void main(String[] args) throws IOException {
		
		String homePage="http://www.zlti.com/";
		String URL=" ";
		String url;
		HttpURLConnection huc=null;
		int responsecode=200;
		
		WebDriver driver=new ChromeDriver();
		driver.get(homePage);
		
	List<WebElement>li=	driver.findElements(By.tagName("a"));
	Iterator<WebElement> it=li.iterator();
	
	while(it.hasNext())
	{
		url=it.next().getAttribute("href");
		System.out.println(url);
		if(url==null || url.isEmpty())
		{
			System.out.println("There is no URL configured");
			continue;
		}
		
		try 
		{
			huc=(HttpURLConnection)(new URL(url)).openConnection();
		}
		catch (MalformedURLException e)
		{
			
			e.printStackTrace();
		} catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		
		
	}
	
	huc.setRequestMethod("HEAD");
	responsecode=huc.getResponseCode();
	if(responsecode>=400)
	{
		System.out.println("URL is broken");
	}
	
	else
		System.out.println("URL is Valid");
	
	
	
	
		
		
		
		
		
		

	}

}
