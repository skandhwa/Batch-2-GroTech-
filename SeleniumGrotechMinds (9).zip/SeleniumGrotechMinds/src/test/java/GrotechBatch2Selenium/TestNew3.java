package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TestNew3 {
	
	public static void main(String[] args) throws InterruptedException {
		WebDriver d1 = new ChromeDriver();
		d1.get("https://demo.automationtesting.in/Register.html");
		d1.manage().window().maximize();
		//------------------------Title, Source and refresh---------------------------//
		String w1=d1.getTitle();
		//String w2=d1.getPageSource();
		System.out.println(w1);
		//System.out.println(w2);
        //d1.navigate().refresh();
		//------------------------First and Last name---------------------------------//
		d1.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Akshit");
		d1.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Slathia");
		//-----------------------------Address---------------------------------------------------------------------------------------//
		d1.findElement(By.xpath("//textarea[@class='form-control ng-pristine ng-untouched ng-valid']")).sendKeys("107,Gurgoan,HR,India");
		//-----------------------------Email and Phone-----------------------------------//
		d1.findElement(By.xpath("//input[@type='email']")).sendKeys("akshit@gmail.com");
		d1.findElement(By.xpath("//input[@type='tel']")).sendKeys("5151515151");
		//-----------------------------Upload----------------------------------------//
		WebElement uploadElement=d1.findElement(By.xpath("//input[@id='imagesrc']"));
		uploadElement.sendKeys("C:\\Users\\saura\\OneDrive\\Pictures\\Test123.png");
		//-----------------------------Radio button and Checkbox----------------------------------------//
		d1.findElement(By.xpath("(//input[contains(@value,\"Male\")])[1]")).click();
		d1.findElement(By.xpath("//input[@id='checkbox1']")).click();
		d1.findElement(By.xpath("//input[@id='checkbox2']")).click();
		Thread.sleep(3000);
JavascriptExecutor js=  (JavascriptExecutor)d1;
		
		js.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(3000);
		//-------------------------------Language-------------------------------------------//
		d1.findElement(By.xpath("//div[@id='msdd']")).click();
		d1.findElement(By.xpath("//a[text()='Arabic']")).click();
		d1.findElement(By.xpath("//a[text()='Danish']")).click();
		d1.findElement(By.xpath("//a[text()='English']")).click();
	    
		
		//-------------------------------Skills and Country--------------------------------//
		Select s1 = new Select(d1.findElement(By.xpath("//select[@id='Skills']")));
		Thread.sleep(1000);
		s1.selectByValue("Adobe InDesign");
		Select s2 = new Select(d1.findElement(By.xpath("//select[@id='country']")));
		Thread.sleep(1000);
		s2.selectByValue("Bangladesh");
		Select s3 = new Select(d1.findElement(By.xpath("//select[@id='yearbox']")));
		s3.selectByValue("1997");
		Select s4 = new Select(d1.findElement(By.xpath("//select[@placeholder='Month']")));
		s4.selectByValue("March");
		Select s5 = new Select(d1.findElement(By.xpath("//select[@id='daybox']")));
		s5.selectByValue("2");
		//--------------------------------Password----------------------------------------//
		String password1="akshit12";
		String password2="akshit12";
		d1.findElement(By.xpath("//input[@id='firstpassword']")).sendKeys(password1);
		d1.findElement(By.xpath("//input[@id='secondpassword']")).sendKeys(password2);
		if(password1.equals(password2))
		{
			System.out.println("password is same");
		}
		else
		{
		    System.out.println("password is not same");
		}
		//--------------------------------submit----------------------------------------//
		d1.findElement(By.xpath("//button[@id='submitbtn']")).click();
		
	} 


}
