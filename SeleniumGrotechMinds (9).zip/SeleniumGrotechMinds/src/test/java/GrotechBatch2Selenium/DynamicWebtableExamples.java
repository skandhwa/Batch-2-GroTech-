package GrotechBatch2Selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DynamicWebtableExamples {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/saura/Downloads/WebTable.html");
		String before_xpath="//table/tbody/tr[";
		String after_xpath="]/td[2]";
	List rows=	driver.findElements(By.xpath("//table/tbody/tr"));
	  
	int rowsize=rows.size();///6
	
	for(int i=2;i<=rowsize;i++)///i=2,2<=6,i=3,3<=6
	{
		String Name=driver.findElement(By.xpath(before_xpath+i+after_xpath)).getText();
		System.out.println(Name);
		Thread.sleep(3000);
		if(Name.contains("Jessica"))
		{
			driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[1]/input")).click();
			break;
			
			
			
		}
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		

	}

}
