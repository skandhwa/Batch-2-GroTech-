package stepDefinition;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	
	
	@Before
	public void beforetest()
	{
		System.out.println("This is before scenario");
	}
	
	@After
	public void Aftertest()
	{
		System.out.println("This is after scenario");
	}
	
	
	
	@Before("@sanity2,@sanity1")
	public void beforescenario2()
	{
		System.out.println("This is tagged before scenario");
	}
	
	@After("@sanity2")
	public void afterscenario2()
	{
		System.out.println("This is tagged after scenario");
	}
	
	
	@Given("user launches the application")
	public void user_launches_the_application() {
	   
		System.out.println("I am login code");
		
	}

	@Given("user enters the {string}")
	public void user_enters_the(String string) {
		System.out.println("I am userid code");
	}

	@Given("user will enter the {string}")
	public void user_will_enter_the(String string) {
		System.out.println("I am password code");
	}

	@When("user will click on login button")
	public void user_will_click_on_login_button() {
		System.out.println("I am click on submit button code");
	}

	@Then("user will be navigated to home page")
	public void user_will_be_navigated_to_home_page() {
		System.out.println("I am navigating to home page code");
	}

	

}
