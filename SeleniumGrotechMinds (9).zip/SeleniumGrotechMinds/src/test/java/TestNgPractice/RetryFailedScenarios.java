package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RetryFailedScenarios {
	
	@Test(retryAnalyzer=TestNgPractice.RetryAnalyzer.class)
	public void display()
	{
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.google.com");
		String Title=driver.getTitle();
		Assert.assertEquals(Title, "google1");
	}
	
	
	

}
