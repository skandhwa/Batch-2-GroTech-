package TestNgPractice;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(ListenersTestNgEx.class)

public class ExecuteTestNgTest extends DriverInitialization {
	
	@Test
	public void getResult()
	{
		getDriver().get("https://www.google.com");
		String Title=getDriver().getTitle();
		Assert.assertEquals(Title, "google1");
	}
	
	

}
