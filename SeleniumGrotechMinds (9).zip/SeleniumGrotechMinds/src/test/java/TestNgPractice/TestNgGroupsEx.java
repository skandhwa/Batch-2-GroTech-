package TestNgPractice;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgGroupsEx {
	
	@Test(groups={"sanity"})
	public void display()
	{
		System.out.println("Hello i sanity group");
	}
	
	@Test(groups={"regression"})
	public void display1()
	{
		System.out.println("Hello I am regression group");
	}
	
	@Test(groups={"sanity"})
	public void display2()
	{
		System.out.println("Hello i am also sanity group");
		Reporter.log("Hello This is Saurabh test scenarios");
	}
	
	@Test(dependsOnGroups= {"sanity"})
	public void msg2()
	{
		System.out.println("I am message 2");
	}
	
	
	
	

}
