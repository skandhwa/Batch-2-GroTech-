package TestNgPractice;
import org.testng.annotations.Test;
public class TestNgDependentCases {
	
	@Test
	public void Login()
	{
		int x=9/0;
		System.out.println(x);
		System.out.println("I am login scenario");
	}
	
	@Test(dependsOnMethods= {"Login"})
	public void Search_a_Product()
	{
		System.out.println("I am search product scenario");
	}
	
	@Test(dependsOnMethods= {"Login","Search_a_Product"})
	public void AddtoCart()
	{
		System.out.println("I am Add to cart  scenario");
	}
	
	@Test
	public void paymentgateway()
	{
		System.out.println("I am payment gateway  scenario");
	}
	

}
