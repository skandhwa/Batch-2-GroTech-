package TestNgPractice;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


@Listeners(ListenersTestNgEx.class)
public class TestNGListenerExample {
	
	@Test
	public void display()
	{
		System.out.println("Hello");
	}
	
	@Test
	public void msg()
	{
		int x=9/0;
		System.out.println(x);
	}
	
	@Test()
	public void test()
	{
		int y=9/3;
		System.out.println(y);
	}
	

}
