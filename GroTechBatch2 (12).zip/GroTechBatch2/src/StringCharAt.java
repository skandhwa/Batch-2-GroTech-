
public class StringCharAt {

	public static void main(String[] args) {
		
		String str="India";
	char ch=	str.charAt(1);
	System.out.println(ch);
	
	int x=str.length();
	System.out.println(x);
		
	
	String str2="Australia   ";
	int y=str2.length();
	System.out.println(y);
		

	}

}
