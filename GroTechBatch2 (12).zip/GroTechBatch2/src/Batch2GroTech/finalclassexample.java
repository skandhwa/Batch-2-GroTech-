package Batch2GroTech;

//final class BD
//{
//	void display()
//	{
//		System.out.println("I am display method");
//	}
//}
//
//
//class BE extends BD
//{
//	void display2()
//	{
//		System.out.println("I am display2 method");
//	}
//}
//public class finalclassexample {
//
//	public static void main(String[] args) {
//		
//		BE obj=new BE();
//		obj.display();
//		obj.display2();

//	}

//}
