package Batch2GroTech;

public class largestbetween3numbers {

	public static void main(String[] args) {
		
		int a=10;
		int b=12;
		int c=11;
		int d=30;
		
		
		if(a>b && a>c && a>d)//10>12
		{
			System.out.println("a is largest");
		}
		
		else if(b>c && b>a && b>d)//12>11,12>10,12>30
		{
			System.out.println("b is largest");
		}
		
		else if(c>d && c>a && c>b)///11>30
		{
			System.out.println("c is largest");
		}
		
		else
		{
			System.out.println("d is largest");
		}
		
		

	}

}
