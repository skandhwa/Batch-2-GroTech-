package Batch2GroTech;

class Bike13
{
	int cube(final int n)
	{
		//n=n+2;
		return n*n*n;
	}
}



public class finalparameterexample {

	public static void main(String[] args) {
		
		Bike13 obj=new Bike13();
	System.out.println(obj.cube(3));	
		
		

	}

}
