package Batch2GroTech;

class AB
{
	void display()
	{
		System.out.println("I am class AB");
	}
}

class CD extends AB
{
	void display1()
	{
		System.out.println("I am in CD");
	}
}
public class SingleLevelInheritance {

	public static void main(String[] args) {
		
		//AB obj=new AB();
		CD obj=new CD();
		obj.display();
		obj.display1();
		
		
		

	}

}
