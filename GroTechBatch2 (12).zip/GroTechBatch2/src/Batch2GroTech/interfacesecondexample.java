package Batch2GroTech;

interface Bank10
{
	float rateofintrest();
}

class SBI10 implements Bank10
{
	public float rateofintrest()
	{
		return 9.5f;
	}
}

class PNB implements Bank10
{
	public float rateofintrest()
	{
		return 8.5f;
	}
}
public class interfacesecondexample {

	public static void main(String[] args) {
		
		Bank10 obj=new SBI10();
	System.out.println(obj.rateofintrest());	
		
		Bank10 obj1=new PNB();
		System.out.println(obj1.rateofintrest());	
		
		

	}

}
