package Batch2GroTech;

public class ArmstrongNumber {

	public static void main(String[] args) {
	
		int n,r,sum=0,temp;
		n=15;
		temp=n;
		
		while(n>0)////153>0///15>0//1>0/
		{
			r=n%10;///r=3///r=15%10=5//1%10=1
			sum=sum+(r*r*r);///s=0+27=27///s=27+125=152///s=152+1=153
			n=n/10;///153/10=15//15/10=1//0
		}
		
		if(temp==sum)
		{
			System.out.println("It is Armstrong");
		}
		else
		{
			System.out.println("Not Armstrong");
		}
		

	}

}
