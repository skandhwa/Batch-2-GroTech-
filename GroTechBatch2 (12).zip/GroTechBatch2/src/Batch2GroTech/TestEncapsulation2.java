package Batch2GroTech;

public class TestEncapsulation2 {

	public static void main(String[] args) {
		
		TestEncapsulation obj=new TestEncapsulation();
		obj.setName1("Saurabh");
		
	System.out.println(obj.getName1());	
		
		

	}

}
