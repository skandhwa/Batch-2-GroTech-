package Batch2GroTech;

class Bank2
{
	 int getRateofIntrest(int Q1,int Q2)
	{
		return Q1+Q2;
	}
	
	void display()
	{
		System.out.println("hello");
	}
	
	
}

class SBI2 extends Bank2
{
	int getRateofIntrest(int Q1,int Q2)
	{
		return Q1+Q2;
		
		
	}
	
	
}

class UBI2 extends Bank2
{
	int getRateofIntrest(int Q1,int Q2)
	{
		return Q1+Q2;
	}
}

public class MethodOveridingforStatic {

	public static void main(String[] args) {
		

	}

}
