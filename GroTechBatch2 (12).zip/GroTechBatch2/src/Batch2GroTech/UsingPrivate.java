package Batch2GroTech;

class AZ
{
	private int t=10;
}



public class UsingPrivate extends AZ {
	
	private static int x=10;

	public static void main(String[] args) {
		
		
		int y=x+10;
		System.out.println(y);
		
		
		

	}

}
