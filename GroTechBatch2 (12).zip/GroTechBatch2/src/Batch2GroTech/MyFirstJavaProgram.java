package Batch2GroTech;

public class MyFirstJavaProgram {
	static int d=10;
	
	public void add()
	{
		int x=10;
		int y=20;
		System.out.println(x+y);
	}
	

	public static void main(String[] args) {
		
		MyFirstJavaProgram obj=new MyFirstJavaProgram();
		
		
		System.out.println("Hello World");
		System.out.println("Hello World New ");
		
		int a=5;
		int b=6;
		int c=a+b;
		System.out.println(c);
		
		String x="Saurabh";
		
	}

}
