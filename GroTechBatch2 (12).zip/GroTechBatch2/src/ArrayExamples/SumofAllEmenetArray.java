package ArrayExamples;

public class SumofAllEmenetArray {

	public static void main(String[] args) {
		
		int []a=new int [] {12,45,67,89};
		int sum=0;
		
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		
		System.out.println("The sum is "+sum);
		
		

	}

}
