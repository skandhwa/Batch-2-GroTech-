package ArrayExamples;

public class JaggedArray {

	public static void main(String[] args) {
		
		int [][]a= {{1,2,3},{6,9},{56,78,9,12}};
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		

	}

}
