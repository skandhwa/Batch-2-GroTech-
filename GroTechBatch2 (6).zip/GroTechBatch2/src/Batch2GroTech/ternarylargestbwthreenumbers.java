package Batch2GroTech;

public class ternarylargestbwthreenumbers {

	public static void main(String[] args) {
         
		int a=10;
		int b=18;
		int c=40;
		
		int max;
		max=(a>b)?(a>c ?a:c):(b>c ?b:c);//18>40
		
		System.out.println(max);
		


	}

}
