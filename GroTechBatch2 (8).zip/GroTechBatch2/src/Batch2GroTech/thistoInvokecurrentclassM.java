package Batch2GroTech;

class AX
{
	void m()
	{
		System.out.println("hello");
	}
	
	void n()
	{
		System.out.println("How are you");
		m();///this.m
	}
}




public class thistoInvokecurrentclassM {

	public static void main(String[] args) {
		AX obj=new AX();
		obj.n();

	}

}
