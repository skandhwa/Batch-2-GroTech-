package Batch2GroTech;

public class ConstructorOverload {
	int id;
	String name;
	float fee;
	int age;
	
	ConstructorOverload(int i,String n,float f)
	{
		id=i;//name of instance should on LHS
		name=n;
		fee=f;
	}
	ConstructorOverload(int i,String n,float f,int a)
	{
		id=i;//name of instance should on LHS
		name=n;
		fee=f;
		age=a;
	}
	
	void display()
	{
		System.out.println(id+" "+name+" "+fee+" "+age);
	}
	
	
	
	
	public static void main(String[] args) {
		
		ConstructorOverload obj=new ConstructorOverload(222,"Ramesh",4500.50f);
		ConstructorOverload obj2=new ConstructorOverload(422,"Mahesh",7500.50f,16);
		obj.display();
		obj2.display();
		

	}

}
