//package Batch2GroTech;
//
//class Bike11
//{
//	 final void run()
//	{
//		System.out.println("Bike is running");
//	}
//}
//
//class Bike12 extends Bike11
//{
//	final void run()
//	{
//		System.out.println("I am overriden method");
//	}
//}
//
//class Bike13 extends Bike11
//{
//	void run()
//	{
//		
//	}
//}
//
//
//public class finalmethodExample {
//
//	public static void main(String[] args) {
//		
//		Bike12 obj=new Bike12();
//		obj.run();
//		
//
//	}
//
//}
