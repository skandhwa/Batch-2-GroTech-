package Batch2GroTech;

public class ConstructorsEx {
	
	int display()
	{
		int a=10;
		int b=20;
		int c= a+b;
		return c;
		
	}
	
	void test()
	{
		System.out.println("Hello all");
	}
	
	public static void main(String[] args) {
		
		ConstructorsEx obj=new ConstructorsEx();
	System.out.println(obj.display());	
	
	obj.test();
	
		
		
		

	}

}
