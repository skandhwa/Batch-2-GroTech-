package Batch2GroTech;

public class StaticBlockExample {
	
	static
	{
		System.out.println("I am static block");
		
		}
	
	
	

	public static void main(String[] args) {
		
		System.out.println("I am main method");
		

	}

}
