package GrotechBatch2Selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlerts {

	public static void main(String[] args) throws InterruptedException {
		
		///SIMPLE ALERT
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Alerts.html");
//		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
		
		
		//CONFIRMATION ALERT
		
		driver.manage().window().maximize();
//		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		Thread.sleep(3000);
//		//driver.switchTo().alert().accept();
//		driver.switchTo().alert().dismiss();
//	WebElement ele=	driver.findElement(By.xpath("//p[@id='demo']"));
//String TextVal=	ele.getText();
//System.out.println(TextVal);


   //Prompt Alert

driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
Alert alert=driver.switchTo().alert();
Thread.sleep(5000);
alert.sendKeys("Saurabh");
alert.accept();
String Value=driver.findElement(By.xpath("//p[@id='demo1']")).getText();
System.out.println(Value);

String str2=Value.substring(6, 14);
System.out.println(str2);




		
		
		
		
		
		
		
		
		

	}

}
