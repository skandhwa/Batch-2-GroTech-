package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebElementCommands2 {

	public static void main(String[] args) {
		
		WebDriver driver=new FirefoxDriver();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
		try
		{
	WebElement ele=	driver.findElement(By.xpath("//input[@id='vfb-900']"));
	
	
	
	if(ele.isDisplayed()==true)
	{
		ele.sendKeys("Saurabh");
	}
	else
		System.out.println("It will Throw an exception");
	}
	
	catch(Exception e)
	{
		System.out.println("Exception caught");
	}
	
		
		
		
		
		

	
	
	
	
	
	
	
	
	
	
	

}
	
	}
