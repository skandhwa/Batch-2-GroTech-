package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommand3 {

	public static void main(String[] args) throws InterruptedException {
		
WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.google.com/");
		
	String URL=	driver.getCurrentUrl();
	System.out.println(URL);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[@class='gb_y'])[1]")).click();
		Thread.sleep(3000);
		String URL2=	driver.getCurrentUrl();
		System.out.println(URL2);
		
	String PgSource=	driver.getPageSource();
	System.out.println(PgSource);
	int x=PgSource.length();
	System.out.println(x);
	
	
		
		
		
		

	}

}
