package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebElementCommands4 {

	public static void main(String[] args) {
		
		WebDriver driver=new FirefoxDriver();
		driver.get("https://nxtgenaiacademy.com/demo-site/");
	WebElement ele=	driver.findElement(By.xpath("(//label[@class='vfb-desc'])[1]"));
	String val=	ele.getText();
	System.out.println(val);
	
	

	}

}
