package GrotechBatch2Selenium;



import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class getLocationWebElement {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
	WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
	
       Point p=ele.getLocation();
       System.out.println("X Coordinate is " +p.x);
       System.out.println("Y Coordinate is " +p.y);
       
       Dimension d=ele.getSize();
    System.out.println(d.height);   
    System.out.println(d.width);   
       
       
	
		

	}

}
