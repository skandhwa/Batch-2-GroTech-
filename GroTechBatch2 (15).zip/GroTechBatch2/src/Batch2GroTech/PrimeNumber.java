package Batch2GroTech;

public class PrimeNumber {

	public static void main(String[] args) {
		int a=17;
        int q=a/2;
        int flag=0;
        
        if(a==0||a==1)
        {
        	System.out.println(" this is not prime");
        }
        
        else
        {
        	for(int i=2;i<=q;i++)
        	{
        		if(a%i==0)
        		{
        			System.out.println(" is not prime");
        			flag=1;
        			break;
        		}
        	}
        	
        	if(flag==0)
        	{
        		System.out.println(" is prime");
        	}
        }
        
	}

}
