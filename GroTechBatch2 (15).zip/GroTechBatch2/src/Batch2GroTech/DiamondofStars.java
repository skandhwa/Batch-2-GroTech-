package Batch2GroTech;

public class DiamondofStars {

	public static void main(String[] args) {
		
		
		
		
		

	}

}
