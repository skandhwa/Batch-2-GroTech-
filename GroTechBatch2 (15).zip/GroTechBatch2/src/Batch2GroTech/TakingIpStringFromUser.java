package Batch2GroTech;

import java.util.Scanner;

public class TakingIpStringFromUser {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");
		String str=sc.nextLine();
		
		System.out.println("Enter a FLoat Variable");
		float y=sc.nextFloat();
		
		
		
		
		
		int x=str.length();
		System.out.println(x);
		

	}

}
