//package Batch2GroTech;
//
//public class UsingPrivateAccessModifier {
//	
//	
//	private int x=20;
//	private void test()
//	{
//		int y=x+10;
//	}
//	
//	
//	
//	private void display()
//	{
//		System.out.println("Hello");
//	}
//
//	public static void main(String[] args) 
//	{
//		UsingPrivateAccessModifier obj=new UsingPrivateAccessModifier();
//		obj.x;
//
//	}
//
//}
