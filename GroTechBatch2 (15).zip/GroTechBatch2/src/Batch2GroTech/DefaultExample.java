package Batch2GroTech;

public class BZ
{
	void display()
	{
		System.out.println("Hello");
	}
}



public class DefaultExample {

	public static void main(String[] args) {
		
		BZ obj=new BZ();
		obj.display();
		

	}

}
