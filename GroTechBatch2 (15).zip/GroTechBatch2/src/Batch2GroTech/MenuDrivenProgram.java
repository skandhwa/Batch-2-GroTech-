package Batch2GroTech;

import java.util.Scanner;

public class MenuDrivenProgram {

	public static void main(String[] args) {
		
		int a ,b,c;
		int choice;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter your choice");
		choice =sc.nextInt();
		
//		while(true)
//		{
		
		switch(choice)
		{
		case 1:
			
			System.out.println("Enter the first number");
			a=sc.nextInt();
			System.out.println("Enter the second number");
			b=sc.nextInt();
			c=a+b;
			System.out.println("The sum is  " +c);
			//break;
			
        case 2:
			
			System.out.println("Enter the first number");
			a=sc.nextInt();
			System.out.println("Enter the second number");
			b=sc.nextInt();
			c=a-b;
			System.out.println("The difference is  " +c);
			//break;
			
         case 3:
			
			System.out.println("Enter the first number");
			a=sc.nextInt();
			System.out.println("Enter the second number");
			b=sc.nextInt();
			c=a*b;
			System.out.println("The product is  " +c);
		//	break;
			
         case 4:
 			
 			System.out.println("Enter the first number");
 			a=sc.nextInt();
 			System.out.println("Enter the second number");
 			b=sc.nextInt();
 			c=a/b;
 			System.out.println("The quotient is  " +c);
 			//break;
 			
 			default:
 				System.out.println("This is an incorrect value");
			
		
		
		}
		//}
		
		

	}

}
