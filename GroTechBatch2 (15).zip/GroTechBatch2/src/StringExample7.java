
public class StringExample7 {

	public static void main(String[] args) {
	
		String str="Java is very robust";
		String []word=str.split(" ");
		
//		for(int i=0;i<word.length;i++)
//		{
//			System.out.println(word[3]);
//		}
		
		for(String w:word)
		{
			System.out.println(w);
		}
		
		

	}

}
