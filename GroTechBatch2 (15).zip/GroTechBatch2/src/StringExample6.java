
public class StringExample6 {

	public static void main(String[] args) {
		
		String str="India is a vast country";
	String str1=	str.replace("is", "was");
		System.out.println(str1);
		
		String str2="Java Basic ";
		
		String str3=str2.replace("a", "c");
		
		System.out.println(str3);
		
		

	}

}
