
public class StringExample10 {

	public static void main(String[] args) {
		
		
		String str5="   Hello Java   ";
		System.out.println(str5);
		
		String str6=str5.trim();
		System.out.println(str6);

	}

}
