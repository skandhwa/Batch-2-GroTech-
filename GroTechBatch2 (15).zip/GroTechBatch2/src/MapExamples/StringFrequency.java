package MapExamples;

import java.util.HashMap;
import java.util.Map;

public class StringFrequency {

	public static void main(String[] args) {
		
		String str="India is a secular country and India is secular democratic country";
		Map<String,Integer> mp=new HashMap<String,Integer>();
		
		String []words=str.split(" ");
		
		for(String word:words)///
		{
			if(mp.containsKey(word))///
			{
				mp.put(word,(mp.get(word)+1));//mp.put(India,(2))
			}
			
			else
			{
				mp.put(word, 1);///mp.put(India,1),mp.put(is,1)
			}
		}
		
		for(Map.Entry entry:mp.entrySet())
		{
			System.out.println(entry.getKey()+"   "+entry.getValue());
		}
		
		
		
		
		
		
		
		
		
		

	}

}
