package MapExamples;

import java.util.EnumMap;

public class EnumClassExample {
	
	public enum seasons
	{
		WINTER,SUMMER,RAINY;
	}
	

	public static void main(String[] args) {
		
		
		EnumMap<seasons,String>mp=	new EnumMap<seasons,String>(seasons.class);
		mp.put(seasons.RAINY, "1");
		mp.put(seasons.SUMMER, "2");
		mp.put(seasons.WINTER, "3");
		
		for(seasons x:seasons.values())
		{
			System.out.println(x);
		}
		
		
		

	}

}
