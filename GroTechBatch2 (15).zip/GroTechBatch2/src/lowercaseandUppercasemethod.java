
public class lowercaseandUppercasemethod {

	public static void main(String[] args) {
		
		String str="INDIA";
		String str1=str.toLowerCase();
		System.out.println(str1);
		
		String str2="india";
		String str3=str2.toUpperCase();
		System.out.println(str3);
		
		
		

	}

}
