package ArrayExamples;

public class GetLargestElement {
	
	public static int largest(int []a,int total)
	{
		int t;
		
		for(int i=0;i<total;i++)//i=0,i<6
		{
			for(int j=i+1;j<total;j++)//j=1,1<6
			{
				if(a[i]>a[j])///
				{
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
	}
	return a[4];
	}
	

	public static void main(String[] args) 
	{
		
		int a[]= {12,3,4,28,67,9};
	    System.out.println(largest(a,6));
		

	}

}
