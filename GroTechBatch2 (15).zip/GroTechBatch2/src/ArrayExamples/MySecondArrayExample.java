package ArrayExamples;

public class MySecondArrayExample {

	public static void main(String[] args) {
		
		int a[]= {22,12,45,67};
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		for(int x:a)
		{
			System.out.println(x);
		}
		

	}

}
