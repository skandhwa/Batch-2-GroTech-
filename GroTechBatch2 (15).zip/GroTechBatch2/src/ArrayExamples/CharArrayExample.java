package ArrayExamples;

public class CharArrayExample {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		char a[]=str.toCharArray();
		
		for(char c:a)
		{
			System.out.println(c);
		}
		

	}

}
