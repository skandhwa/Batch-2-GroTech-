
public class StringBuilderExample {

	public static void main(String[] args) {
		
		StringBuilder sb=new StringBuilder("Saurabh");
		sb.append("Kandhway");
		System.out.println(sb);
		
		sb.insert(1,"Java");
		System.out.println(sb);
		

	}

}
