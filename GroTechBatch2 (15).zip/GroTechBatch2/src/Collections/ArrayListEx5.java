package Collections;

import java.util.ArrayList;

public class ArrayListEx5 {

	public static void main(String[] args) {
		
		ArrayList<String> fruit=new ArrayList<String>();
		fruit.add("Apple");
		fruit.add("Kiwi");
		fruit.add("Cucumber");
		
		ArrayList<String> Vegetables=new ArrayList<String>();
		Vegetables.add("Potato");
		Vegetables.add("Cucumber");
		Vegetables.add("Capsicum");
		
		
		
		Vegetables.retainAll(fruit);
		
		System.out.println(Vegetables);
		

	}

}
