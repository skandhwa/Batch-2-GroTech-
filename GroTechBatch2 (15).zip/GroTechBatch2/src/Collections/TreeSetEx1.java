package Collections;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		TreeSet<String> a=new TreeSet<String>();
		a.add("Saurabh");
		a.add("Gaurabh");
		a.add("Ajit");
		a.add("Zaheer");
		
//		Iterator<String> itr=a.iterator();
//		while(itr.hasNext())
//		{
//			System.out.println(itr.next());
//		}
		
		
		Iterator<String> itr=a.descendingIterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		

	}

}
