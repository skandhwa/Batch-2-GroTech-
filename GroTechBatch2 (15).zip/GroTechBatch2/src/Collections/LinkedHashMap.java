package Collections;

public class LinkedHashMap {

	public static void main(String[] args) {
		
		Map<String,String> mp=new LinkedHashMap<String,String>();
		

	}

}
