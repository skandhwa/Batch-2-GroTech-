package Collections;

import java.util.TreeSet;

public class TreeSetEx2 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(34);
		s1.add(24);
		s1.add(46);
		s1.add(99);
		
	System.out.println(s1.pollFirst());	
		
	System.out.println(s1.pollLast());	
		

	}

}
