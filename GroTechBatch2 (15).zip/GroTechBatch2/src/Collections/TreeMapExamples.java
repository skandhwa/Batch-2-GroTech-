package Collections;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapExamples {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		mp.put(500, "Manish");
		mp.put(600, "Rahul");
		mp.put(650, "Vikas");
		mp.put(800, "Mohan");
		
		
		for(Map.Entry m1:mp.entrySet())
		{o
			System.out.print(m1.getKey()+" ");
			System.out.print(m1.getValue());
			System.out.println();
		}
		
	System.out.println("Last Entry to Map"+mp.pollLastEntry());	
	
	System.out.println("Celining value is"+mp.ceilingEntry(620));
		
		
		System.out.println(mp.descendingMap());
		
		System.out.println(mp.headMap(600,true));
		System.out.println(mp.tailMap(600,false));
		System.out.println(mp.subMap(500,false ,800,true));
		

	}

}
