package Collections;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		
		
		Queue<String> q1=new PriorityQueue<String>();
		
		q1.add("pineapple");
		q1.add("mango");
		q1.add("kiwi");
		q1.add("apple");
		q1.add("melon");
		
		System.out.println("Elements present in queue are");
		for(String x:q1)
		{
			System.out.println(x);
		}
		
		q1.remove();
		
		System.out.println("Priniting elements after deletion");
		
		for(String x:q1)
		{
			System.out.println(x);
		}
		//It will return the element at the rear end 
	System.out.println("Element at peek position is " + q1.peek());	
		
		

	}

}
