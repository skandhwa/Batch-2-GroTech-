package Collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(100, "Manish");
		mp.put(200, "Rahul");
		mp.put(300, "Vikas");
		mp.put(400, "Mohan");
	//	mp.put(400, "Rohan");
		
		int x=mp.size();
		System.out.println("size of map is" +x);
		
		mp.remove(100);
		mp.replace(200, "Ratul");
		
		
	//	System.out.println(mp);
		
		//for(String x:m1)
		
		Map<Integer,String> mp1=new HashMap<Integer,String>();
		mp1.put(500, "Manish");
		mp1.put(600, "Rahul");
		mp1.put(700, "Vikas");
		mp1.put(800, "Mohan");
		
		for(Map.Entry m1:mp.entrySet())
		{
		System.out.print(m1.getKey());	
		System.out.print(	m1.getValue());
		System.out.println();
		}
		System.out.println();
		System.out.println();
		mp.putIfAbsent(350, "Girish");
		
		
		
		for(Map.Entry m1:mp.entrySet())
		{
		System.out.print(m1.getKey());	
		System.out.print(	m1.getValue());
		System.out.println();
		}
		
		System.out.println();
		System.out.println();
		
		mp.putAll(mp1);
		
		for(Map.Entry m1:mp.entrySet())
		{
		System.out.print(m1.getKey());	
		System.out.print(	m1.getValue());
		System.out.println();
		}
		
		
		
		
		

	}

}
