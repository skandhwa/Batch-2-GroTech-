package Collections;

import java.util.HashSet;
import java.util.Set;

public class HashSetExample1 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("mango");
		s1.add("banana");
		s1.add("kiwi");
		s1.add("kiwi");
		s1.add("melon");
		s1.add("grapes");
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		
		

	}

}
