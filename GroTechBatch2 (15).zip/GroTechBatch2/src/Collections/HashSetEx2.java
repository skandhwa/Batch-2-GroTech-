package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class HashSetEx2 {

	public static void main(String[] args) {
		
            Set<Integer> s1=new HashSet<Integer>();
            s1.add(45);
            s1.add(34);
            s1.add(67);
            
            System.out.println("Elements in Set are ");
            System.out.println();
            
            for(int x:s1)
            {
            	System.out.println(x);
            }
            
           ArrayList<Integer>a=new ArrayList<Integer>();
           
           a.add(90);
           a.add(56);
           a.add(75);
           a.add(75);
           
           System.out.println("Elements in ArrayList  are ");
           System.out.println();
           
           for(int y:a)
           {
        	   System.out.println(y);
           }
           
           System.out.println("Element after merging are");
           
           s1.addAll(a);
           
           for(int z:s1)
           {
        	   System.out.println(z);
           }
           
           
           
      boolean flag=     s1.contains(75);
      System.out.println(flag);
      
      
           
           
      System.out.println("Element after clearing are");
           s1.clear();
           
           for(int z:s1)
           {
        	   System.out.println(z);
           }
           
           
           
           
           
            
            
             
	}

}
