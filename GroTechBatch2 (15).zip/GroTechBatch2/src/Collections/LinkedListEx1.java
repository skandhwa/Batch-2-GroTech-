package Collections;

import java.util.LinkedList;

public class LinkedListEx1 {

	public static void main(String[] args) {
		
		LinkedList<String> li=new LinkedList<String>();
		li.add("Manish");
		li.add("Rahul");
		li.add("Mohit");
		
		for(String z:li)
		{
			System.out.println(z);
		}
		

	}

}
