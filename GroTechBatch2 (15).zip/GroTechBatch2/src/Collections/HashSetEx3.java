package Collections;

import java.util.HashSet;
import java.util.Set;

public class HashSetEx3 {

	public static void main(String[] args) {
		
		 Set<Integer> s1=new HashSet<Integer>();
         s1.add(45);
         s1.add(34);
         s1.add(67);
         s1.add(97);
         s1.add(77);
         
      boolean flag3=   s1.isEmpty();
      System.out.println(flag3);
      
      s1.remove(97);
      
         
         
         System.out.println("Elements in Set are ");
         System.out.println();
         
         for(int x:s1)
         {
         	System.out.println(x);
         }
         
         Set<Integer> s2=new HashSet<Integer>();
         s2.add(45);
         s2.add(34);
         s2.add(657);
         
         System.out.println("Elements in Set are ");
         System.out.println();
         
         for(int x:s2)
         {
         	System.out.println(x);
         }
         
         
         System.out.println("Does the set contains all element  "  + s1.containsAll(s2));
         
         
         

	}

}
