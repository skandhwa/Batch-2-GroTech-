package Collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx1 {

	public static void main(String[] args) {
		
		 Set<Integer> s1=new LinkedHashSet<Integer>();
         s1.add(45);
         s1.add(34);
         s1.add(67);
         s1.add(97);
         s1.add(77);
         s1.add(77);
         
         System.out.println("Elements in set are");
         for(int x:s1)
         {
         	System.out.println(x);
         }

	}

}
