package Collections;

import java.util.TreeSet;

public class TreeSetEx3 {

	public static void main(String[] args) {
		
		TreeSet<String> a=new TreeSet<String>();
		a.add("A");
		a.add("B");
		a.add("C");
		a.add("D");
		a.add("E");
		
		for(String x:a)
		{
			System.out.println(x);
		}
		
		
	System.out.println(a.descendingSet());	
	
	System.out.println(a.headSet("C",false));
	System.out.println(a.tailSet("C",false));
	
	System.out.println(	a.subSet("A",false,"E",true));
	
	
	
	
	

	}

}
