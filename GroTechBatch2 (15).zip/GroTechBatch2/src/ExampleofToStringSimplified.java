class Employee7
{
	int id;
	String name;
	String location;

Employee7(int id,String name,String location)
{
	this.id=id;
	this.name=name;
	this.location=location;
}
	


void display()
{
	System.out.println(id+"  "+name+" "+location);
	
}
}
public class ExampleofToStringSimplified {

	public static void main(String[] args) {
		Employee7 obj=new Employee7(100,"Saurabh","Kolkata");
		obj.display();
		
		

	}

}
