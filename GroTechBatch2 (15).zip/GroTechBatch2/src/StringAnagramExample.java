import java.util.Arrays;

public class StringAnagramExample {

	public static void main(String[] args) {
		String str1="BRAT";
		String str2="GRAB";
		
		str1=str1.toLowerCase();
		str2=str2.toLowerCase();
		
		if(str1.length()==str2.length())
		{
			char []charray1=str1.toCharArray();
			char []charray2=str2.toCharArray();
			
			Arrays.sort(charray1);
			Arrays.sort(charray2);
			
		boolean flag=	Arrays.equals(charray1, charray2);
		
		if(flag)
		{
			System.out.println("The two String are anagram");
		}
		else
		{
			System.out.println("The two String are not anagram");
		}
		}
		else
		{
			System.out.println("Since length are not same the two string cannot be anagram");
		}
		
		

	}

}
