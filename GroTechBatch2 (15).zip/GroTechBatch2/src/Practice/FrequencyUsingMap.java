package Practice;

import java.util.HashMap;
import java.util.Map;

public class FrequencyUsingMap {
	
	public static void main(String args[])
    {
        int a[] = {10, 20, 20, 10, 10, 20, 5, 20,50,50,60,60,60,80,90};
        int n = a.length;
        
        Map<Integer, Integer> mp = new HashMap<Integer,Integer>();
 
        
        for (int i = 0; i < n; i++)
        {
            if (mp.containsKey(a[i]))
            {
                mp.put(a[i], mp.get(a[i]) + 1);
            }
            else
            {
                mp.put(a[i], 1);
            }
        }
        
        for (Map.Entry entry : mp.entrySet())
        {
            System.out.println(entry.getKey() + " " + entry.getValue());
        }
    }
 
    
    
    }
	
