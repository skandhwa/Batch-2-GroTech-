package FileOperations;

import java.io.File;

public class DeleteFile {

	public static void main(String[] args) {
		
		
		File obj=new File("E:\\File Operations\\Test5.txt");
	boolean flag=	obj.delete();
	System.out.println("FIle is deleted ");
		

	}

}
