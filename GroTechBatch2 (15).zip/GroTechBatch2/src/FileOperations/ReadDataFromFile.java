package FileOperations;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadDataFromFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		File obj=new File("E:\\File Operations\\Test5.txt");
		Scanner sc=new Scanner(obj);
		
		while(sc.hasNextLine())
		{
		String data=	sc.nextLine();
		System.out.println(data);
		}
		sc.close();
		

	}

}
