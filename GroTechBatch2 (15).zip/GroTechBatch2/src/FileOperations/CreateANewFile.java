package FileOperations;

import java.io.File;
import java.io.IOException;

public class CreateANewFile {

	public static void main(String[] args) throws IOException  {
		
		File obj=new File("E:\\File Operations\\Test4.txt");
	boolean flag=	obj.createNewFile();
	
	if(flag==true)
	{
		System.out.println("File is created");
	String FileName=	obj.getName();
	System.out.println(FileName);
	String Path=obj.getAbsolutePath();
	System.out.println(Path);
	}
	else
	{
		System.out.println("File is not created");
	}
	
	
	boolean flag2=obj.canWrite();
	System.out.println(flag2);
	
	boolean flag3=obj.canRead();
	System.out.println(flag3);
	
	long x=obj.length();
	System.out.println(x);
		
		

	}

}
