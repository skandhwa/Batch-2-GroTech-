package FileOperations;

import java.io.FileWriter;
import java.io.IOException;

public class WriteToAFile {

	public static void main(String[] args) throws IOException {
		
		FileWriter obj=new FileWriter("E:\\File Operations\\Test5.txt");
		obj.write("I am Creating a Java File");
		
		obj.close();
		
		
		
		

	}

}


