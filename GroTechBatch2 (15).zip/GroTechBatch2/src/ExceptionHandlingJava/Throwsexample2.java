package ExceptionHandlingJava;

import java.io.IOException;

public class Throwsexample2 {

	public static void main(String[] args) throws IOException  {
		
		int x=10;
		int y=x+20;
		System.out.println(y);
		throw new IOException("You are not elligible");
		

	}

}
