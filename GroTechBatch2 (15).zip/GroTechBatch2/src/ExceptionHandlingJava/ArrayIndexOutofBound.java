package ExceptionHandlingJava;

public class ArrayIndexOutofBound {

	public static void main(String[] args) {
		
		try
		{
		int a[]=new int [10];
		a[15]=25;
		}
		
		
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Exception Caught" +e);
		}
		
		
		
		int x=10;
		int y=x+15;
		System.out.println(y);
		
		
		

	}

}
