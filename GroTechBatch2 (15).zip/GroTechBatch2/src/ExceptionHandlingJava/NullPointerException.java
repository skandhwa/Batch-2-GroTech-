package ExceptionHandlingJava;

public class NullPointerException {

	public static void main(String[] args) {
		
		try
		{
		String str="Saurabh";
		int x=str.length();
		System.out.println(x);
		}
		
		catch(Exception e)
		{
			System.out.println("Exception Handled" +e);
		}
		
		
		
		int p=10;
		int y=p+15;
		System.out.println(y);
		

	}

}
