package ExceptionHandlingJava;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class throwclauseforCheckedException {
	
	public static void M() throws FileNotFoundException
	{
		File obj=new File("E:\\File Operations\\Test9.txt");
		Scanner sc=new Scanner(obj);
		
		while(sc.hasNextLine())
		{
		String data=	sc.nextLine();
		System.out.println(data);
		}
		sc.close();
		System.out.println("Hello");
		
		throw new FileNotFoundException();
		
		
		
	}
		
	public static void main(String[] args) throws FileNotFoundException {
		
		try
		{
		M();
		
		}
		
		catch(Exception e)
		{
			System.out.println("Exception caught" +e);
		}
		
		System.out.println("Hello");
		
		
		
		

	}

}
