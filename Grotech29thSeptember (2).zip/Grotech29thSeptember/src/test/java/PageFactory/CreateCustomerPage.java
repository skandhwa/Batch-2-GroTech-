package PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CreateCustomerPage {
	
	WebDriver driver;
	public CreateCustomerPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//a[@href='addcustomerpage.php']")
	WebElement New_Customer_link;
	
	@FindBy(xpath="//input[@name='name']")
	WebElement Customer_name;
	
	@FindBy(xpath="//input[@value='m']")
	WebElement Gender;
	
	@FindBy(xpath="//input[@id='dob']")
	WebElement date_Of_birth;
	
	
	
	public void clickNewCustomerlink()
	{
		New_Customer_link.click();
	}
	
	public void addCustomername(String text)
	{
		Customer_name.sendKeys(text);
	}
	
	public void selectGender()
	{
		Gender.click();
	}
	
	public void enterDateOfBirth(String text2)
	{
		date_Of_birth.sendKeys(text2);
	}
	
	
	

}
