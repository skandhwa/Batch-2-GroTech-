package CONSTANTS;

public class constants {
	
	public static final String URLPATH="C:\\Users\\saura\\OneDrive\\Documents\\TestData2607.xlsx";
	public static final String SCREENSHOTPATH="D:\\ScreenShot Folder\\"+Math.random()+"test.png";
	

}
