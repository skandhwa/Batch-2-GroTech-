package TestNgPractice;


import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AssertionsTestngExample {
	
	@Test
	public void test()
	{
		String Actualtitle="google";
		String Actualtitle2="google2";
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String ExpectedTitle=driver.getTitle();
		ExpectedTitle=	ExpectedTitle.toLowerCase();
		Assert.assertEquals(ExpectedTitle, Actualtitle);
		//Assert.assertTrue(false);
		
	boolean flag=	driver.findElement(By.xpath("//textarea[@id='APjFqb']")).isDisplayed();
	
	Assert.assertTrue(flag);
	
	int a[]=new int[] {3,4,5};
	int b[]=new int[] {9,4,5};
	boolean x= Arrays.equals(a,b);
	System.out.println("The value of array equals is  "+x);
	
	Assert.assertFalse(x);
	
	Assert.assertNotEquals(ExpectedTitle, Actualtitle);
	
	
	int t=20;
	int v=t+30;
	System.out.println(v);
		
		
		
		
		
		
		
	}
	

}
