package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDataProviderExample1 {
	
	WebDriver driver;
	@DataProvider(name="dp1")
	public Object[][] dpmethod()
	
	{
		return new Object[][]
				{
			{"Java"},{"Selenium"},{"Basic"}
			
				};
		
		
	}
	
	
	
	@Test(dataProvider="dp1")
	public void searchvalue(String keyword)
	{
		
		System.out.println("Starting my test case");
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
	ele.sendKeys(keyword);
	System.out.println(keyword);
	Reporter.log(keyword);
	ele.sendKeys(Keys.ENTER);
	
	
	
	}
	
	@Test(dataProvider="dp1")
	public void search1value(String value)
	{
		
		System.out.println("Starting my test case");
		driver=new FirefoxDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
	ele.sendKeys(value);
	System.out.println(value);
	Reporter.log(value);
	ele.sendKeys(Keys.ENTER);
	
	
	
	}
	
	
	
	
	

}
