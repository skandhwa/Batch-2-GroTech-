package TestNgPractice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgParameterExample1 {
	
	@Test
	@Parameters({"b","e","f"})
	public void sum(int g,int h,int i)
	{
		int result=g+h+i;
		System.out.println(result);
	}
	
	
	@Test
	@Parameters({"b","e","f"})
	public void subtract(int g,int h,int i)
	{
		int result=g+h-i;
		System.out.println(result);
	}
	
	@Test
	@Parameters({"b","e","f"})
	public void multiply(int g,int h,int i)
	{
		int result=g*h*i;
		System.out.println(result);
	}
	
	
	
	

}
