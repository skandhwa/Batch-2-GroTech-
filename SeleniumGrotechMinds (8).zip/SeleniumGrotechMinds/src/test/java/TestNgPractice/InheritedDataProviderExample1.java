package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class InheritedDataProviderExample1 {
	
	WebDriver driver;
	
	@Test(dataProvider="dp1",dataProviderClass=TestNgDataProviderExample1.class)
	public void search(String k)
	{
		System.out.println("Starting my test case");
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
	ele.sendKeys(k);
	System.out.println(k);
	Reporter.log(k);
	ele.sendKeys(Keys.ENTER);
	}
	

}
