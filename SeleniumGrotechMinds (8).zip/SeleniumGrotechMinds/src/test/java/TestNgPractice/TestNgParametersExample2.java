package TestNgPractice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgParametersExample2 {
	
	@Test
	@Parameters("Kiwi")
	public void display(String x)
	{
		System.out.println("Fruit name is" +x);
	}
	
	@Test
	@Parameters("Mango")
	public void display1(String y)
	{
		System.out.println("Fruit name is" +y);
	}
	
	

}
