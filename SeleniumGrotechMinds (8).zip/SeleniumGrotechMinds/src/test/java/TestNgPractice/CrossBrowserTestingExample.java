package TestNgPractice;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserTestingExample {
	
	public WebDriver driver;
	
	@Parameters("browser")
	
	@BeforeClass
	public void prereq(String browser)
	{
		if(browser.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			
		}
		else if(browser.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
		}
		
		driver.get("https://www.google.com");
		
	}
	
	@Test
	public void login()
	{
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("Selenium testing");
	}
	
	@AfterClass
	public void closedriver() throws InterruptedException
	{
		//Thread.sleep(5000);
		driver.quit();
	}
	
	
	

}
