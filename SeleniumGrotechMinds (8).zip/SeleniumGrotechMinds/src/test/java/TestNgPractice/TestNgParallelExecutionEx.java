package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestNgParallelExecutionEx {

	public WebDriver driver;
	
	@Test
	public void FirefoxTestEx()
	{
		driver=new FirefoxDriver();
		driver.get("https://www.google.com");
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("Selenium testing");
		
	}
	
	

	@Test
	public void ChromeTestEx()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("Selenium testing");
		
	}
	
	
	@Test
	public void ChromeTestEx2()
	{
		driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		//driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("Selenium testing");
		
	}
	
	
}
