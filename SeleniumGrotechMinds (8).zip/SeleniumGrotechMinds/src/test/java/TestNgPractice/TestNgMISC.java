package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgMISC {
	
	@Test(timeOut=5000)
	public void test() throws InterruptedException
	{
		Thread.sleep(1000);
		System.out.println("Hello I am display");
	}
	
	@Test(invocationCount=3)
	public void display()
	{
		System.out.println("Hello I am Saurabh");
		
	}
	
	
	

}
