package GrotechBatch2Selenium;
	import java.time.Duration;
import java.util.List;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	/**
	@author Mandeep Kaur
	@Date 28 April,2020
	*/
	public class DynamicWebTableExample {
	public static void main(String[] args) throws InterruptedException {
	
	WebDriver driver = new ChromeDriver(); 
	
	driver.get("C:\\Users\\saura\\Downloads\\WebTable.html");
	driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
	
//	String before_xpath = "//table/tbody/tr["; 
//	
//	String after_xpath = "]/td[2]";
//	
//	List rows = driver.findElements(By.xpath("//table/tbody/tr"));
//	
//	int rowSize = rows.size();
//	
//	System.out.println(rowSize);
//	
//	for (int i = 2; i <= rowSize; i++) 
//	{
//	String firstNames = driver.findElement(By.xpath(before_xpath + i + after_xpath)).getText();
//	System.out.println(firstNames);
//	
//	if (firstNames.contains("Will")) {
//	
//	driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[1]/input")).click(); System.out.println("candidate has been selected");
//	//break;
//	}
//	}
	
//	driver.navigate().refresh();
//	Thread.sleep(3000);
	
	
	driver.findElement(By.xpath("//td[contains(text(),'Jessica')]//preceding-sibling::"+ "td//input[@type='checkbox']")) .click();
	Thread.sleep(5000);
	
	
	driver.close();
	}
	}


