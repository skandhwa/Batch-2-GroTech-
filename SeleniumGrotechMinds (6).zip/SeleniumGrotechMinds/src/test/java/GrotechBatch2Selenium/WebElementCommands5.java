package GrotechBatch2Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebElementCommands5 {

	public static void main(String[] args) {
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.tutorialspoint.com/selenium/selenium_automation_practice.htm");
	WebElement ele=	driver.findElement(By.xpath("//input[@name='firstname']"));
	String value=	ele.getAttribute("type");
	System.out.println(value);
	
String tagvalue=	ele.getTagName();

System.out.println(tagvalue);

	}

}
