package GrotechBatch2Selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class GetOptionsFromDropdown {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
	WebElement ele=	driver.findElement(By.xpath("//select[@id='continents']"));
		
	Select oselect=new Select(ele);
	
	List<WebElement> li=oselect.getOptions();
	for(WebElement x:li)
	{
		System.out.println(x.getText());
	}
	
	if(li.contains("Asia")==true)
	{
		System.out.println("Asia is a part of dropdown");
	}
	
	
	
	
	
	
		
		

	}

}
