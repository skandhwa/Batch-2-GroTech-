package ExceptionHandling;

public class NestedTryCatchBlock {

	public static void main(String[] args) {
		
		try
		{
			String str="Manish";
			int p=str.length();
			System.out.println(p);
			
			
			try
			{
		
		
		
		int a=20/0;
		System.out.println(a);
			}
			
			catch (Exception e)
			{
				System.out.println("caught with "+e);
			}
			
			
			try
			{
				int []b=new int[3];
				b[4]=20;
			}
			
			catch(Exception e)
			{
				System.out.println("caught with  "+e);
			}
		
		
		}
		
		catch(Exception e)
		{
			System.out.println("This is outer try block catch statement ");
		}
		

	}

}
