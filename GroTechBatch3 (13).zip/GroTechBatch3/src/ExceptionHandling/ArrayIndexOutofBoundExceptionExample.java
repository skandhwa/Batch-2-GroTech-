package ExceptionHandling;

public class ArrayIndexOutofBoundExceptionExample {

	public static void main(String[] args) {
		
		try
		{
		
		int []a=new int[3];
		a[0]=12;
		a[1]=30;
		a[2]=40;
		a[3]=50;
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		int f=20;
		int b=30;
		int c=f+b;
		System.out.println(c);
		
		
		

	}

}
