package ExceptionHandling;

public class MultiCatchBlockException {

	public static void main(String[] args) {
		
		try
		{
		
			
            String s=null;
			
			int t=s.length();
			System.out.println(t);
			
			int x=20;
			int y=x/0;
			System.out.println(y);
			
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		catch(NullPointerException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		int f=20;
		int b=30;
		int c=f+b;
		System.out.println(c);
		
		
		
		
		
		

	}

}
