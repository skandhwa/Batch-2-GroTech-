package ExceptionHandling;

public class UncheckedExceptionExample {

	public static void main(String[] args) {

         try {
			Thread.sleep(4000);
			
			
		} 
         
         catch (InterruptedException e) {
			
			e.printStackTrace();
		}

	}

}
