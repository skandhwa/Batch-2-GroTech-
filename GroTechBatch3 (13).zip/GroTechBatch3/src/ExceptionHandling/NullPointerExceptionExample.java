package ExceptionHandling;

public class NullPointerExceptionExample {

	public static void main(String[] args) {
		
		try
		{
			String s=null;
			
			int x=s.length();
			System.out.println(x);
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		int f=20;
		int b=30;
		int c=f+b;
		System.out.println(c);
		

	}

}
