package ExceptionHandling;

public class finalizeExample {

	public static void main(String[] args) {
		
		
		finalizeExample obj=new finalizeExample();
		obj=null;
		System.gc();
		
	}
		
		protected void finalize()
		{
			System.out.println("finalize method is being called");
		}

	}


