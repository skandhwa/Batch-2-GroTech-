package AccessModifierDemo;

import basicConcepts.ProtectedExample1;

public class ProtectedExample3 extends ProtectedExample1 {

	public static void main(String[] args) {
		
		ProtectedExample3 obj=new ProtectedExample3();
		obj.display();

	}

}
