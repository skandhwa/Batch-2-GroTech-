package AccessModifierDemo;

import basicConcepts.ProtectedExample1;

public class ProtectedExample {

	public static void main(String[] args) {
		
		ProtectedExample1 obj=new ProtectedExample1();
		obj.display();
		

	}

}
