package AccessModifierDemo;

import basicConcepts.PublicExample1;

public class PublicExample4 extends PublicExample1 {

	public static void main(String[] args) {
		
		PublicExample4 obj=new PublicExample4();
		obj.display();
		
		
	}

}
