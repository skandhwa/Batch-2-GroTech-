package basicConcepts;

public class ProtectedExample1 

{
	protected void display()
	{
		System.out.println("Hello Saurabh");
	}
	
	

	public static void main(String[] args) {
		
		ProtectedExample1 obj=new ProtectedExample1();
		obj.display();
		
		

	}

}
