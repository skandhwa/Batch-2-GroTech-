package basicConcepts;

public class breakexample {

	public static void main(String[] args) {
		
		for(int i=0;i<10;i++)//i=0, 0<10//1<10//2//3....
		{
			if(i==5)
			{
				continue;
			}
			System.out.println(i);
		}

	}

}
