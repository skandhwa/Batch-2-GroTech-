package basicConcepts;

class AX///superclass
{
	void display()
	{
		System.out.println("hello");
	}
}

class BX extends AX///child class is also called as subclass
{
	void test()
	{
		System.out.println("How are u");
	}
}

class CX extends BX
{
	void message()
	{
		System.out.println("i am printig a message");
	}
}

public class MultiLevelInheritance {

	public static void main(String[] args) {
		CX obj=new CX();
		obj.display();
		obj.message();
		obj.test();
		

	}

}
