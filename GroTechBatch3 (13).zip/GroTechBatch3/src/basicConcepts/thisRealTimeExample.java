package basicConcepts;

class Employee10
{
	int id;
	String name;
	String address;
	float salary;
	Employee10(int id,String name,String address)
	{
		this.id=id;
		this.name=name;
		this.address=address;
	}
	Employee10(int id,String name,String address,float salary)
	{
		this(id,name,address);//reusing constructor
		this.salary=salary;
		
	}
	
	void display()
	{
		System.out.println(name +"  "+ id+"  "+ address + " "+salary);
	}
	
}
public class thisRealTimeExample {

	public static void main(String[] args) {
		//Employee10 obj=new Employee10(1234,"mahesh","kolkata");
		Employee10 obj1=new Employee10(3234,"Ramesh","Mumbai",45000f);
		
		Employee10 obj2=new Employee10(3234,"Ramesh","Mumbai",45000f);
		//obj.display();
		obj1.display();
		
		
	}

}
