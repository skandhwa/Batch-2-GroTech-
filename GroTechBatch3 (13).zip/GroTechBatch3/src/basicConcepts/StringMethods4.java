package basicConcepts;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="Saurabh";
	String str1=	str.replace('a', 'z');
		System.out.println(str1);
		
		
		String str2="java is a robust java is structured";
		
		String str3=str2.replaceAll("java", "python");
		System.out.println(str3);
		
		String str4="    India     Rebublic";
		str4=str4.trim();
		System.out.println(str4);
		
		
		
		

	}

}
