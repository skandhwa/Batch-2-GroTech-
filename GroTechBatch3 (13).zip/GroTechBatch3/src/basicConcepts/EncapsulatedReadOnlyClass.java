package basicConcepts;

public class EncapsulatedReadOnlyClass {
	
	
	private String name="Amit";
	private int salary=80000;

	public int getSalary() {
		return salary;
	}

	public String getName() {
		return name;
	}

	
	
	

}
