package basicConcepts;
class Bank
{
	static int getRateOfIntrest()
	{
		return 10;
	}
}

class IDFC extends Bank
{
	static int getRateOfIntrest()
	{
		return 11;
	}
}

class AUS extends Bank
{
	static int getRateOfIntrest()
	{
		return 12;
	}
}

class RBL extends Bank
{
	static int getRateOfIntrest()
	{
		return 14;
	}
}
public class MethodOveridingExample2 {

	public static void main(String[] args) {
		
	System.out.println(Bank.getRateOfIntrest());	
		

	}

}
