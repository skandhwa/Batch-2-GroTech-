package basicConcepts;

public class NestedForLoopExample2 {

	public static void main(String[] args) {
		
		int weeks=2;
		int days=7;
		
		for(int i=1;i<=weeks;++i)//i=1;1<=2
			
		{
			System.out.println("Week is" +i);//1
			
			for(int j=1;j<=days;++j)//j=1,1<=7//j=2,2<=7//3<=7
			{
				System.out.println("Day is" +j);//1//2
			}
		}
		
		
		
		

	}

}
