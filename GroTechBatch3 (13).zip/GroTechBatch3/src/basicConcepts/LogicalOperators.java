package basicConcepts;

public class LogicalOperators {

	public static void main(String[] args) {
		
		int x=10;
		int y=9;
		int z=12;
		int m=14;
		
		if(x<m && z>m && y<x && m>x)//10<14,12>14,9<10,14>10
		{
			System.out.println("I am true");
		}
		else
			System.out.println("I am false");
		

	}

}
