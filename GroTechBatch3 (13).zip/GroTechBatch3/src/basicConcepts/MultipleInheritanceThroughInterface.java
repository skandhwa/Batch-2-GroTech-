package basicConcepts;

interface print1
{
	void print();
	
}

interface show1
{
	void show();
}

class ET implements print1,show1
{
	public void print()
	{
		System.out.println("I am print method");
	}
	
	public void show()
	{
		System.out.println("I am show method");
	}
	
}

public class MultipleInheritanceThroughInterface {

	public static void main(String[] args) {
		
		print1 obj=new ET();
		show1 obj1=new ET();
		
		obj.print();
		obj1.show();

	}

}
