package basicConcepts;

public class StringExample1 {

	public static void main(String[] args) {
		
		char []ch= {'s','a','u','r','a','b'};
		
		String s=new String(ch);///Converting character array to string
		String str="Saurabh";///using string literal
		
		String str1=new String("India");//non pool heap 
		
		
		
		String str2="Saurabh";
String	str3=	str2.concat("Kandhway");
		System.out.println(str3);
		
		
		
		
		

	}

}
