package basicConcepts;

final class CF
{
	void display()
	{
		System.out.println("hello");
	}
}

class CG extends CF
{
	void test()
	{
		System.out.println("Hi");
	}
}
public class finalClassExample {

	public static void main(String[] args) {
		
		CG obj=new CG();
		obj.display();
		obj.test();
		

	}

}
