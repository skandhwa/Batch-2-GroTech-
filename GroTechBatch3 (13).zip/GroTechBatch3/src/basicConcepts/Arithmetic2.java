package basicConcepts;

public class Arithmetic2 {

	public static void main(String[] args) {
		
		int x=11;
		int y=90;
		int z=y/x;
		System.out.println(z);
		
		System.out.println(20<<3);//20*2^3=20*8=160
		System.out.println(120>>4);//120/2^4=120/16

	}

}
