package basicConcepts;

public class StringMethod1 {

	public static void main(String[] args) {
		
		String str="India";
	int x=	str.length();
	System.out.println(x);
	
char ch=	str.charAt(2);
System.out.println(ch);


	str=str.toUpperCase();
	System.out.println(str);
	
	str=str.toLowerCase();
	System.out.println(str);
	
	
	
		

	}

}
