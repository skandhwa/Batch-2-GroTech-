package basicConcepts;

public class NestedForLoop {

	public static void main(String[] args) {
		
		int n=5;
		
		for(int i=0;i<n;i++)//////0<5//1<5
		{
			for(int j=0;j<n;j++)//j=0,0<5
			{
				for(int k=0;k<n;k++)
				{
					System.out.println(i+"   "+j+"   "+k);
				}
				
				
			}
			
		}
		
		

	}

}
