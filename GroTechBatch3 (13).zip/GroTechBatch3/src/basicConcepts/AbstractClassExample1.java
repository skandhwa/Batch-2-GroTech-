package basicConcepts;

abstract class DB
{
	void display()
	{
		System.out.println("I am display method");
	}
	
	abstract void test();
	
	abstract void msg();
	
	void test2()
	{
		System.out.println("I am test2 method");
	}
	
	
}

class DY extends DB
{
	void test()
	{
		System.out.println("I am test method");
	}
	void msg()
	{
		System.out.println("I am message method");
	}
}

class DZ extends DB
{
	void msg()
	{
		System.out.println("I am message method");
	}
	void test()
	{
		System.out.println("I am test method");
	}
}


public class AbstractClassExample1 {

	public static void main(String[] args) {
		
		DY obj=new DY();
		obj.display();
		obj.test();
		
		DZ obj1=new DZ();
		obj1.msg();
		
		

	}

}
