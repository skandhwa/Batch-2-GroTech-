package basicConcepts;

public class ifelseExample {

	public static void main(String[] args) {
		
		int x=10;
		int y=20;
		int z=30;
		
		if(y>x && y>z || z>x)
		{
			System.out.println("Hello");
		}
		
		
		else
		{
			System.out.println("Hi");
		}
		
		

	}

}
