package basicConcepts;

public class LargestBwThreeNumberUsingElseIf {

	public static void main(String[] args) {
		
		int a=10;
		int b=30;
		int c=30;
		int d=50;
		
		if(a>=b && a>=c && a>=d)
		{
			System.out.println("a is largest");
		}
		
		else if(b>=a && b>=c && b>=d)//30>=10,30>=30
		{
			System.out.println("b is largest");
		}
		
		else if(c>=a && c>=b && c>=d)
		{
			System.out.println("c is largest");
		}
		
		else 
		{
			System.out.println("d is largest");
		}
		

	}

}
