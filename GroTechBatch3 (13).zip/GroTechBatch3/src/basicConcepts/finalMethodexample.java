package basicConcepts;

class Train2
{
	final  void run()
	{
		System.out.println("Train is running");
	}
	
	
	
}
class Rajdhani extends Train2
{
	//void run()
	{
		System.out.println("Train is running with 100kmph");
	}
}

public class finalMethodexample {

	public static void main(String[] args) {
		
		Train2 obj=new Train2();
		obj.run();
		Rajdhani obj1=new Rajdhani();
		obj1.run();
		

	}

}
