package basicConcepts;

class Employee3
{
	String name;
	int id;
	int age;
	
	
	
	Employee3(String n,int i)
	{
		name=n;
		id=i;
	//	System.out.println("Hello how are you");
	}
	
	Employee3(String n,int i,int a)
	{
		name=n;
		id=i;
		age=a;
		}
	
	Employee3(int i,int a)
	{
		//name=n;
		id=i;
		age=a;
		}
	
	
	void display()
	{
		System.out.println("The employee id is  "+id);
		System.out.println("The name is  "+name);
		System.out.println("The age is  "+age);
		System.out.println();
		
	}
	
	
	
}
	
	public class MultipleParameterizedConstructor {

	public static void main(String[] args) {
		
		Employee3 obj=new Employee3("manoj",3456);
		//Employee3 obj=new Employee3("ramesh",1856);
		obj.display();
		
		Employee3 obj1=new Employee3("Ritesh",8456,38);
		obj1.display();
		
		Employee3 obj2=new Employee3();
		
		
		
		
		

	}

}
