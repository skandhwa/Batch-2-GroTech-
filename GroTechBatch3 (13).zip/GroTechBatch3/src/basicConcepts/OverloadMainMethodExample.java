package basicConcepts;

public class OverloadMainMethodExample {
	
	public static void main(String args)
	{
		System.out.println("main with string");
	}
	
	public static void main()
	{
		System.out.println("main without string");
	}
	
	

	public static void main(String[] args) {
		
		OverloadMainMethodExample obj=new OverloadMainMethodExample();
		obj.main();
		obj.main("Hello");
		

	}

}
