package basicConcepts;

import java.io.File;

public class GetFileLengthofExistingFile {

	public static void main(String[] args) {
		
		File f=new File("D:\\03rdOctoberFileNew\\SaurabhNew.txt");
		long x=f.length();
		System.out.println(x);

	}

}
