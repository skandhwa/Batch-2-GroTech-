package basicConcepts;

class DZA
{
	void display()
	{
		System.out.println("Hello Saurabh 20th Sep");
	}
}

public class DefaultExample1 {

	public static void main(String[] args) {
		
		DZA obj=new DZA();
		obj.display();
		
		

		
		
	}

}
