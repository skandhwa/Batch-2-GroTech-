package basicConcepts;

class AZ
{
	 private int y=30;
	private void display()
	{
		System.out.println("Hello Java");
		int z=y+50;
	}
	
	void test()
	{
		System.out.println(y);
	}
	
}

class BZ
{
	private int z=40;
}




public class PrivateExample {
	
	public static void main(String[] args) {
		
		AZ obj=new AZ();
		obj.display();
		
		obj.test();
		
	System.out.println(obj.y);	
		
		
		

		
		

	}

}
