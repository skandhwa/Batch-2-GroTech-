package basicConcepts;

public class UnaryOperators {

	public static void main(String[] args) {
		//postfix
		//prefix
		
		int x=5;//assignment
		int y=6;
		int z=9;
		
		if(y==x)//checking the equality
		
		
		 
		
		
	//	int a=x-- + ++y + ++x; ///5 + 7 + (++4)=5+7+5;
		
	//	int b= ++y - --x + --y + y++;
		
		   //   7 - 4   + 6 + 6=
		
		int c = z++ + x-- + y-- - ++x + ++y - --z;
		        
	//	        9   + 5   + 6  -  5 +  6  - 9 
 
		
		///  z=10  x=4 ,y=5
		
		System.out.println(c);
		
		
		
		
		
		
		
//		a++
//		a--
//		
//		
//		--b
//		++b
		

	}

}
