package basicConcepts;

class CT
{
	int add(int x,int y)
	{
		return x+y;
	}
	
	float add(int x,float y,float z)
	{
		return x+y+z;
	}
	
	void add()
	{
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
	}
	
	
	
	
}
public class MethodOverloadingExample {

	public static void main(String[] args) {
		
		CT obj=new CT();
	System.out.println(obj.add(23, 44));	
	
	System.out.println(obj.add(23, 56.67f,78.5f));
		

	}

}
