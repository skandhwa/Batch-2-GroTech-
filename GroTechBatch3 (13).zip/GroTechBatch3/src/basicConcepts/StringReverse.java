package basicConcepts;

public class StringReverse {

	public static void main(String[] args) {
		
		String str="sbbs";//
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)//i=4,4>=0//3>=0
		{
		revstr=revstr+	str.charAt(i);//0+a
		}
		
		System.out.println("Original String is "+str);
		System.out.println("Original String is "+revstr);
		
		if(str.equalsIgnoreCase(revstr))
		{
			System.out.println("This is Palindrome");
		}
		
		else
		{
			System.out.println("Not palindrome");
		}
		
		
		
		

	}

}
