package basicConcepts;

public class forLoopExample2 {

	public static void main(String[] args) {
		
		int sum=0;
		int n=10;
		
		for(int i=1;i<n;)///1<10//2<10
		{
			sum+=i;///sum=sum+i;//sum=0+1=1//sum=1+2=3
			i++;
		}
		
		System.out.println(sum);
		

	}

}
