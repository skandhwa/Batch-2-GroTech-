package basicConcepts;

class DA
{
	static int add(int x,int y)
	{
		return x+y;
	}
	
	static float add(float x,float y,int z)
	{
		return x+y+z;
	}
	
}
public class MethodOverloadingwithstatic {

	public static void main(String[] args) {
		
	System.out.println(DA.add(23,56));	
		
	System.out.println	(DA.add(34.67f,88.56f,9));
		

	}

}
