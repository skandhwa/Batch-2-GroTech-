package basicConcepts;

class Pen
{
	Pen()
	{
		int x=10;
		int y=20;
	}
	
	void display()
	{
		int z=x+30;
	}
	
}



public class Constructorexample1 {

	public static void main(String[] args) {
		
		Pen obj=new Pen();
		
		

	}

}
