package basicConcepts;

import java.util.Arrays;

public class CopyArray {

	public static void main(String[] args) {
		
		int []a=new int[] {10,3,5,7};
		int []b=new int[a.length];
		
		for(int i=0;i<a.length;i++)//0<4
		{
			b[i]=a[i];//b[0]=10,b[1]=3
		}
		
		for(int z:b)
		{
			System.out.println(z);
		}
		
		
	String str=	Arrays.toString(b);
	System.out.println(str);
		

	}

}
