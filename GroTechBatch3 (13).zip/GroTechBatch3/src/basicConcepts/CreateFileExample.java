package basicConcepts;

import java.io.File;
import java.io.IOException;

public class CreateFileExample {

	public static void main(String[] args) throws IOException 
	{
		File f=new File("D:\\03rdOctoberFileNew\\+"+Math.random() +"test123.txt");
	boolean flag=	f.createNewFile();
	System.out.println(flag);
	
	String File_Name=f.getName();
	System.out.println(File_Name);
	
	String Path=f.getAbsolutePath();
	System.out.println(Path);
	
	boolean flag2=f.canWrite();
	System.out.println(flag2);
	
	boolean flag3=f.canExecute();
	System.out.println(flag3);
	
	long x=f.length();
	System.out.println(x);
	
	
	

	}

}
