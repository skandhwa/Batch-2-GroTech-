package basicConcepts;

public class ArraySortingExample {

	public static void main(String[] args) {
		
		int a[]=new int[] {23,68,12,19};
		int temp=0;
		
		for(int i=0;i<a.length;i++)//i=1,1<4
		{
			for(int j=i+1;j<a.length;j++)//j=4,2<4
			{
				if(a[i]>a[j])//a[0]>a[2]//a[1]>a[3]
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
				
				
				
				
			}
			
			System.out.println(a[i]);
		}
		
		

	}

}
