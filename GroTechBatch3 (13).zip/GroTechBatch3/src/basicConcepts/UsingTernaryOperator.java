package basicConcepts;

public class UsingTernaryOperator {

	public static void main(String[] args) {
		
		int a=100;
		int b=12;
		
		int max= a>b ? a :b;
		
		System.out.println(max);
		

	}

}
