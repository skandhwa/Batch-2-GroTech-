package basicConcepts;

public class PublicExample1 {
	
	public void display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		PublicExample1 obj=new PublicExample1();
		obj.display();

	}

}
