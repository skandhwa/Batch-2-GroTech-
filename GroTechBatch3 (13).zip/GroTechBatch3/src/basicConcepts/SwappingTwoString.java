package basicConcepts;

public class SwappingTwoString {

	public static void main(String[] args) {
		
		String str1="top";
		String str2="hat";
		
		int x=str1.length();
		int y=str2.length();
		
		
		//a=a+b b=a-b: a=a-b
		
		
//		str1=str1+str2;///str1=tophat
//		
//		str2=str1.substring(0,(str1.length()-str2.length()));//
//		
//		///tophat.substring(0,6-3)
//	//	tophat.substring(0,3)
//		
//		str1=str1.substring(str2.length());
//		
//		///tophat.substring(3)
		
		
		
		str1=str1+str2;
		str2=str1.substring(0,(x-y));
		str1=str1.substring(y);
		
		
		System.out.println(str1);
		System.out.println(str2);
		
		
		
		

	}

}
