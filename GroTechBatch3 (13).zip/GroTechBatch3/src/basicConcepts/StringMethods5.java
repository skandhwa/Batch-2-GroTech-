package basicConcepts;

public class StringMethods5 {

	public static void main(String[] args) {
		
		String str="India is a vast country";
	String []words=	str.split("\\s");
	
	for(String w:words)
	{
		System.out.println(w);
	}
		
		

	
	
	String str1="India @ is a republic country @ and democratic";
	String []words1=str1.split("@");
	

	
	
//	for(String z:words)
//	{
//		System.out.println(z);
//	}
	System.out.println(words1[2]);
	
	
	

}
	
}
