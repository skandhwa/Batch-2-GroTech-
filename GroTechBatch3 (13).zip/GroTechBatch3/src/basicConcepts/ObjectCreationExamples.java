package basicConcepts;

class A
{
	int CP=200;
	float SimpleInt;
	
	void display()
	{
		System.out.println("I am plain display method");
	}
	
	int ProfitLoss()
	{
		int SP=400;
		int Profit=SP-CP;
		return Profit;
	}
	
	float SI()
	{
		int r=5;
		float P=5000.67f;
		int t=5;
		SimpleInt=(P*r*t)/100;
		return SimpleInt;
		
		
	}
	
	
}
public class ObjectCreationExamples {
	
	

	public static void main(String[] args) {
		
		A abc=new A();
		abc.display();
	System.out.println(abc.ProfitLoss());	
	System.out.println(	abc.SI());

	}

}
