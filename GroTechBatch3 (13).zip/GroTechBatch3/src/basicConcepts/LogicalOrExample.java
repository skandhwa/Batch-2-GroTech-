package basicConcepts;

public class LogicalOrExample {

	public static void main(String[] args) {
		int x=10;
		int y=9;
		int z=12;
		int m=14;
		
		
		if(x!=m)
		{
			System.out.println("true");
		}
		
		if(x>m || z>m || y>x || m>x)
		{
			System.out.println("I am true");
		}
		else
			System.out.println("I am false");
		

	}

}
