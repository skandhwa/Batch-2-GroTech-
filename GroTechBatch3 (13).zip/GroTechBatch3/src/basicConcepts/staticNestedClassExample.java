package basicConcepts;

class TestAB
{
	static int data=30;
	
	static class TestCD
	{
		void display()
		{
			System.out.println("Hello");
		}
	}
}


public class staticNestedClassExample {

	public static void main(String[] args) {
		
		TestAB.TestCD obj=new TestAB.TestCD();
		obj.display();
		

	}

}
