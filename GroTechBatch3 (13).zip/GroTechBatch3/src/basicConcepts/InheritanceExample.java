package basicConcepts;

class C
{
	public void display()
	{
		System.out.println("Hello");
	}
}

class D extends C
{
	public void test()
	{
		System.out.println("How are you");
	}
	}
public class InheritanceExample {

	public static void main(String[] args) {
		
		D obj=new D();
		obj.display();
		obj.test();
		
		
		
		

	}

}
