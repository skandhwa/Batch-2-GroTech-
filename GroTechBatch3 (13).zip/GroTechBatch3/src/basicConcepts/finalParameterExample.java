package basicConcepts;

class Fruits
{
	
	Fruits()
	{
		System.out.println("hello");
	}
	
	int price(final int n)
	{
		//n=n+20;
		return (n*4);
	}
	
	
	
}




public class finalParameterExample {

	public static void main(String[] args) {
		
		Fruits obj=new Fruits();
	System.out.println(obj.price(20));	
		

	}

}
