package basicConcepts;

class DC
{
	 void display()
	{
		System.out.println("Hello");
	}
	
	void test()
	{
		System.out.println("I am test method");
	}
}

class DD extends DC
{
	void display()
	{
		System.out.println("Hello Saurabh");
	}
}
public class MethodOverridingExample {

	public static void main(String[] args) {
		
		DD obj=new DD();
		//obj.display();
		obj.test();
		obj.display();
		
		DC obj1=new DC();
		obj1.display();
		
		

	}

}
