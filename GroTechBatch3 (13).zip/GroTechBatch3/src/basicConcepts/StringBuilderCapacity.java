package basicConcepts;

public class StringBuilderCapacity {

	public static void main(String[] args) {
		
		StringBuilder str=new StringBuilder("Hello Saurabh");
		System.out.println(str.capacity());
		
		
		

	}

}
