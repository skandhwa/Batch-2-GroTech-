package basicConcepts;

 class MyFirstJavaProgram {

	public static void main(String[] args) {
		
		
		boolean flag=false;
		boolean flag1=true;
		
		System.out.println(flag);
		System.out.println(flag1);
		
		
		
		
		byte x=-19;///-128 to +127
		
		short y=3268;///-32768 to +32767
		
		int z=1312321432;
		
		long u=123213212232L;
		
		float t=-2132324234324324332432432421321.1232432432432432432432312f;//0.0f
		
		double m=12321323213.34534534534534543;
		
		char g='1';
		
		
		
		

	}

}
