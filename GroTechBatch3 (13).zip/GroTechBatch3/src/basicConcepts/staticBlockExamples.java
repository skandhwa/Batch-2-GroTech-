package basicConcepts;

public class staticBlockExamples {
	
	static
	{
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
		
		
		
	}
	
	

	public static void main(String[] args) {
		
       System.out.println("Hello");
	}

}
