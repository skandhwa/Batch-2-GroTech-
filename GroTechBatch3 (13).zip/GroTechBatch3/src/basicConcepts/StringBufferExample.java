package basicConcepts;

public class StringBufferExample {

	public static void main(String[] args) {
		
//		StringBuffer sb=new StringBuffer("Saurabh");
//		sb.append("Kandhway");
//		System.out.println(sb);
		
		StringBuffer str=new StringBuffer("Saurabh");
//		str.insert(4, "TCS");
//		System.out.println(str);
		
//		str.replace(2, 5, "Infosys");
//		System.out.println(str);
		
		
//		str.replace(3, 6, "UHG");
//		System.out.println(str);
		
		str.replace(1, 4, "HSBC");
		System.out.println(str);
		
		
		
		
		
		

	}

}
