package basicConcepts;

class Pen3
{
	Pen3()
	{
		System.out.println("I am pens constructor");
	}
	
	
	void display()
	{
		System.out.println("I am display method");
	}
}
class Pencil3 extends Pen3
{
	
	Pencil3()
	{
		super();///calling the super class constructor
		System.out.println("I am pencil constructor");
	}
}

public class SuperExample3 {

	public static void main(String[] args) {
		
		Pencil3 obj=new Pencil3();
		
		
		
		

	}

}
