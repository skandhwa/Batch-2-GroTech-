package basicConcepts;

interface show
{
	void print();
}
interface print
{
	void print();
	void display();
}

class Test8 implements show,print
{
	public void print()
	{
		System.out.println("I am print method");
	}
	public void display()
	{
		System.out.println("I am display method");
	}
	
}


public class interfaceExample3 {

	public static void main(String[] args) {
		
		Test8 obj=new Test8();
		obj.print();
		obj.display();
		

	}

}
