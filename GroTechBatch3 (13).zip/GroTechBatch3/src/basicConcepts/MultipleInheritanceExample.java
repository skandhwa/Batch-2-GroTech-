//package basicConcepts;
//
//class AZ
//{
//	void display()
//	{
//		System.out.println("hello");
//	}
//}
//class BZ 
//{
//	void test()
//	{
//		System.out.println("hello how are you");
//	}
//}
//
//class CZ extends AZ,BZ
//{
//	void message()
//	{
//		System.out.println("Hello");
//	}
//	
//	
//}
//public class MultipleInheritanceExample {
//
//	public static void main(String[] args) {
//		
//		CZ obj=new CZ();
//		obj.display();
//		
//
//	}
//
//}
