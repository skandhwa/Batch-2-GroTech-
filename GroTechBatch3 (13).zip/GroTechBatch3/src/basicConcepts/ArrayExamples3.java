package basicConcepts;

import java.util.Arrays;

public class ArrayExamples3 {

	public static void main(String[] args) {
		
		int []a=new int[] {1012,324,516,78};
		int []b=new int[] {912,324,516,78};
		
	int x=	Arrays.compare(a,b);
	System.out.println(x);
	
	
	int []c=new int[] {912,324,516,78};
	int []d=new int[] {1012,324,516,78};
	
boolean y=	Arrays.equals(c,d);
System.out.println(y);



		
		
		
		

	}

}
