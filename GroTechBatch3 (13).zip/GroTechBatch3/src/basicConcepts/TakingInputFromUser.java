package basicConcepts;

import java.util.Scanner;

public class TakingInputFromUser {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first Number");
		//int num1;
		//num1=sc.nextInt();
		
		float num1;
		num1=sc.nextFloat();
		
		System.out.println("Enter second Number");
//		int num2;
//		num2=sc.nextInt();
		
		float num2;
		num2=sc.nextFloat();
		
		//int r=num1+num2;
		
		float r=num1+num2;
		System.out.println("The result is  "+r);
		
		
		
		
		

	}

}
