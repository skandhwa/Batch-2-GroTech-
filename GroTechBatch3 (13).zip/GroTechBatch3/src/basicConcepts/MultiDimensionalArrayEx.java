package basicConcepts;

public class MultiDimensionalArrayEx {

	public static void main(String[] args) {
		
		int a[][]= {{2,3,4},{1,5,7},{9,6,8}};
		
		int x=a.length;
		//System.out.println(x);
		
		for(int i=0;i<x;i++)//i=0;0<3
		{
			for(int j=0;j<x;j++)//0<3
			{
				System.out.print(a[i][j]+" ");
			}
			
			System.out.println();
		}
		
		
		

	}

}
