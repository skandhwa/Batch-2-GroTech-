package basicConcepts;

class Train
{
	static final int speed=200;
	void run()
	{
		//speed=300;
		System.out.println(speed);
		
	}
	
	
}



public class finalVariableexample {

	public static void main(String[] args) {
		
		Train obj=new Train();
		obj.run();
		
		
		
		

	}

}
