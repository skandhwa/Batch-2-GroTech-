
public class StringSecondExample {

	public static void main(String[] args) {
		
		String str="India";
	 str=str.concat("Republic");
		System.out.println(str);
		
		

	}

}
