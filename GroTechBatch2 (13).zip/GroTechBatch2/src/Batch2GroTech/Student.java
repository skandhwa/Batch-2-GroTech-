package Batch2GroTech;

public class Student {
	
	int id;
	String name;
	float attendance;
	
	
	
	void display()
	{
		System.out.println(id+" "+name+" "+attendance);
	}
	

	public static void main(String[] args) {
		
		Student obj=new Student();
		obj.display();
		

	}

}
