package Batch2GroTech;

public class DataTypeExamples {

	public static void main(String[] args) {
		
		boolean x=true;
		
		char ch='A';
		//byte y=129;
		
		short y=3288;
		
		int z=-328483444;//-2147483648 to 2147483647
		
		long d=4544345435243235L;
		
		float p=56565654645654.234324324f;
		
		double s=29743294328463284327453274327.32754327453243273243243827435246352;
		
		

	}

}
