package Batch2GroTech;

public class PrivateExample3 {
	
	
	

	public static void main(String[] args) {
		
		
		

	}

}
