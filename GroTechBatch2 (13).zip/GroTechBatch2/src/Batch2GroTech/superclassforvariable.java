package Batch2GroTech;

class Animal
{
	String color="white";
}

class Dog extends Animal
{
	String color="black";
	
	void printcolor()
	{
		System.out.println(color);
	System.out.println(super.color);	
		
	}
	
	
}
public class superclassforvariable {

	public static void main(String[] args) {
		
		Dog obj=new Dog();
		obj.printcolor();

	}

}
