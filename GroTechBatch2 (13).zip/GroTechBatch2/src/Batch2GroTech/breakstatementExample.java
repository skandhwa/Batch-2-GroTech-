package Batch2GroTech;

public class breakstatementExample {

	public static void main(String[] args) {
		
		
		for(int i=0;i<5;i++)//0//1//2//3
		{
			if(i==3)
			{
				break;
			}
			System.out.println(i);
		}
		
		

	}

}
