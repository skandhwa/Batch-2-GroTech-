package Batch2GroTech;

public class Default7 {
	
	void display()
	{
		System.out.println("Hello How are you");
	}
	

	public static void main(String[] args) {
		
		Default7 obj=new Default7();
		obj.display();

	}

}
