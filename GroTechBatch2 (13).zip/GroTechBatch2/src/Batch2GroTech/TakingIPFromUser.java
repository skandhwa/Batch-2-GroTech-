package Batch2GroTech;

import java.util.Scanner;
import java.awt.AWTEvent;


public class TakingIPFromUser {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number");
		int a;
		a=sc.nextInt();
		
		System.out.println("Enter Second number");
		int b;
		b=sc.nextInt();
		
		System.out.println("Enter third number");
		int c;
		c=sc.nextInt();
		
		int d=a+b+c;
		
		System.out.println("The Total Sum is  "+d);
		
		

	}

}
