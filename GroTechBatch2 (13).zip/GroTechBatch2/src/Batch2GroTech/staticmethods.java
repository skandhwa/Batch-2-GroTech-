package Batch2GroTech;

class Calculate
{
	public static void display()
	{
		System.out.println("Hello");
		int a=20;
		int b=40;
		int c=a+b;
		System.out.println(c);
	}
}


public class staticmethods {

	public static void main(String[] args) {
		
		Calculate.display();

	}

}
