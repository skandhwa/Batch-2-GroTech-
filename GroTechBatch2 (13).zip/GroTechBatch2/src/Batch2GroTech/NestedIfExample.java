package Batch2GroTech;

public class NestedIfExample {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		
		if(a>5)
		{
			System.out.println("I am true");
			if(b>30)
			{
				System.out.println("value of  a and b are more than 5");
			}
		}
		
		

	}

}
