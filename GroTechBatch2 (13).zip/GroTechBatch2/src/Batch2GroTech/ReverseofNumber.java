package Batch2GroTech;

public class ReverseofNumber {

	public static void main(String[] args) {
		
		int num=123;
		int reverse=0;
		int r;
		
		while(num!=0)///123!=0///12!=0//1!=0//0!=0
		{
			r=num%10;//123%10=3//r=12%10=2///r=1%10=1
			reverse=reverse*10+r;//0*10+3=3//reverse=3*10+2=32///reverse=32*10+1=321
			num=num/10;//123/10=12//12/10=1//1/10=0
			
			
			
		}
		
		
		System.out.println("The Reverse value is  "+reverse);
		

	}

}
