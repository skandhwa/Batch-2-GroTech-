
public class StringExamples {

	public static void main(String[] args) {
		
		///String Literal 
		
		String str="Saurabh";
		
		String str2="Saurabh";
		
		///By using new keyword 
		String str3=new String("India");
		
		
		//Converting Char Array to String 
		char []ch= {'I','N','D','I','A'};
		
		String S4=new String(ch);
		

	}

}
