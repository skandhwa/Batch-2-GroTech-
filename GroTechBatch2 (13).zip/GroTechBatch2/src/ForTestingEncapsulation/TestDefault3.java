package ForTestingEncapsulation;
import Batch2GroTech.*;

public class TestDefault3 extends BZ {

	public static void main(String[] args) {
		
		BZ obj=new BZ();
		obj.display();
		
		
		
		

	}

}
