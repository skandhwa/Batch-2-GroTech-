package ArrayExamples;

import java.util.Arrays;

public class ArrayCompareEx {

	public static void main(String[] args) {
		
		int []a= {32,34,21,56};
		//int []b= {23,34,56,78};
		
		int []b= {22,34,21,56};
		
	int x=	Arrays.compare(a,b);
	System.out.println(x);

	}

}
