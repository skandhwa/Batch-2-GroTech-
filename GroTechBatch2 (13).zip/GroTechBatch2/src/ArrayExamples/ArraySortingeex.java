package ArrayExamples;

public class ArraySortingeex {

	public static void main(String[] args) {
		
		int []a=new int[] {12,45,6,78,9};
		int t=0;
		for(int i=0;i<a.length;i++)//i=1,i<5
		{
			for(int j=i+1;j<a.length;j++)//
			{
				if(a[i]>a[j])///
				{
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
			
			System.out.println(a[i]);
		}
		
		

	}

}
