
public class StringExample8 {

	public static void main(String[] args) {
		
		String str1="This is an example of index of method";
		
	int x=	str1.indexOf("python",10);
	System.out.println(x);
		
	}

}
