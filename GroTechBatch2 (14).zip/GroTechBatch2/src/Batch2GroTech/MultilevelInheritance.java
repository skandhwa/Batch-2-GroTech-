package Batch2GroTech;

class AC
{
	void display()
	{
		System.out.println("I am Grandparent");
	}
}

class AD extends AC
{
	int sum (int x,int y)
	{
		return(x+y);
	}
}

class AE extends AD
{
	float difference(int c,int d)
	{
		return c-d;
	}
}
public class MultilevelInheritance {

	public static void main(String[] args) {
		
		AE obj=new AE();
		obj.display();
	System.out.println(obj.difference(34, 10));	
	System.out.println(obj.sum(23, 56));	

	}

}
