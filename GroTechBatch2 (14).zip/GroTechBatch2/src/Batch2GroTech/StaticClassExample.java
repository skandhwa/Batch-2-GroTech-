package Batch2GroTech;

public class StaticClassExample {
	
	
	static class Inner
	{
		 int data=20;
		 void msg()
		{
			System.out.println("value is" +data);
		}
	}
	
	

	public static void main(String[] args) {
		
		StaticClassExample.Inner obj=new StaticClassExample.Inner();
		obj.msg();
		

	}

}
