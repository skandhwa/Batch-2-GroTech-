package Batch2GroTech;

public class WhileLoopExamples {

	public static void main(String[] args) {
		
		int i=11;//initialization
		while(i<=10)//1<=10//2<=10//3<=10//4<=10.....10<=10//11<=10//condition checking
		{
			System.out.println(i);//1//2//3//4....//10
			i++;//increment/decrement
		}
		

	}

}
