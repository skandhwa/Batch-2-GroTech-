package Batch2GroTech;

public class Default8 {

	public static void main(String[] args) {
		
		Default7 obj1=new Default7();
		obj1.display();
		

	}

}
