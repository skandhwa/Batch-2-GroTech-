package Batch2GroTech;

public class TestProtected2 {
	
	void dsiplay()
	{
		
	}
	
	void msg()
	{
		dsiplay();
	}
	

	public static void main(String[] args) {
		
		CF obj2=new CF();
		obj2.msg();
		
	}

}
