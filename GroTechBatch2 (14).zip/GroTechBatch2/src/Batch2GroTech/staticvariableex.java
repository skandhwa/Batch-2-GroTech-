package Batch2GroTech;

class Student8
{
	int rollno;
	String name;
	static String college="IIT Kanpur";
	//String college="KIT";


Student8(int r,String n)
{
	rollno=r;
	name=n;
}

void display()
{
	System.out.println(rollno+" "+name+" "+college);
}

}



public class staticvariableex {


	public static void main(String[] args) {
		
		Student8 obj=new Student8(123,"Manish");
		Student8 obj1=new Student8(456,"Rahul");
		obj.display();
		obj1.display();
		
		
	}
		

	}


