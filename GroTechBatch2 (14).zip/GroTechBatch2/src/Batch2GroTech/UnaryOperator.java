package Batch2GroTech;

public class UnaryOperator {

	public static void main(String[] args) {
		
		int x=7;
		
		int y=8;
		
int 	z=   ++x  + --y + x++  + ++y - ++x  + y++;///x=10, y=8
             
           

          //   = 8+ 7+ 8 + 8 -10 +8

           

System.out.println(z);
		
		
		
		
		x++;//postfix increment 
		
		++x;///prefix increment 
		
		x--;//postfix decrement 
		
		--x;//prefix decrements
		

	}

}
