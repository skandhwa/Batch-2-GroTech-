package Batch2GroTech;

public class PublicExample1 {
	
	public void display()
	{
		System.out.println("Hello I am Public method");
	}

	public static void main(String[] args) {
		PublicExample1 obj=new PublicExample1();
		obj.display();

	}

}
