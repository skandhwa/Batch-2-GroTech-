package Batch2GroTech;

public class UnaryOperator2 {

	public static void main(String[] args) {
	
//		int a=4; // 4+1=5
//		System.out.println(~a);
//		
//		int b=-7;//  -7+1=-6// -(-6)
//		System.out.println(~b);
		
		
		System.out.println(12<<4);///12 * 2pow4= 12*16= 192
		System.out.println(70>>3);/// 70 / 2pow3= 70/8 =8

	}

}
