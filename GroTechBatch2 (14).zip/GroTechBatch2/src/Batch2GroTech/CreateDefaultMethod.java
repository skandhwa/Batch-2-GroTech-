package Batch2GroTech;

interface Drawable8
{
	void draw();
	default void msg()
	{
		System.out.println("I am dfault method");
	}
	
	static int square(int n)
	{
		return n*n;
	}
	
	
	
}

class Square implements Drawable8
{
	public void draw()
	{
		System.out.println("I am draw method");
	}
}

public class CreateDefaultMethod {

	public static void main(String[] args) {
		
		//Square obj=new Square();
		Drawable8 ref=new Square();
		ref.draw();
		ref.msg();
		
		
	System.out.println(Drawable8.square(5));	
		
		
		
		
		

	}

}
