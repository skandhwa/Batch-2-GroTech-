package Batch2GroTech;

class Vehicle
{
	int run(int x,int y)
	{
		System.out.println("vehicle is running");
		return x+y;
		
	}
}

class Bike extends Vehicle
{
	int run(int x,int y)
	{
		System.out.println("Bike is running");
		return x+y;
	}
}




public class MethodOverridingExample {

	public static void main(String[] args) {
		
//		Bike obj=new Bike();
//		obj.run();
		
		Vehicle obj1=new Vehicle();
	System.out.println(obj1.run(4,3));	
		
		
		

	}

}
