package Batch2GroTech;

class A
{
	
	int h=20;
	//static int p=40;
	

	
	void addition()
	{
		
		int x=10;
		int y=20;
		int z=x+y;
		System.out.println(z);
		int p=z+30;//60
		int h=p+20;
		System.out.println(h);
		
	}
	
	void subtraction()
	{
		System.out.println(h);
	}
	
	
	
	
}
public class VariableTutorial {

	public static void main(String[] args) {
		
		A obj=new A();
            obj.addition();
            obj.subtraction();
		
		
		

	}

}
