package ExceptionHandlingJava;

public class NormalFlow {

	public static void main(String[] args) {
		
		
		try
		{
		
		int a=10;
		int b=a/0;
		System.out.println(b);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("Exception caught" +e);
		}
		
		int x=10;
		int y=x+15;
		System.out.println(y);
		

	}

}
