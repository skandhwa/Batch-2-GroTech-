package ExceptionHandlingJava;

public class throwClauseExample {
	
	public  static void checkage(int a)
	{ 
		if(a<18)
		{
			throw new ArithmeticException("You are not elligible");
		}
		
		else
		{
			System.out.println("You can enter and cast your vote");
		}
	}

	public static void main(String[] args) 
	{
		
		checkage(15);
		
		int x=10+1;
		System.out.println(x);
		
		

	}

}
