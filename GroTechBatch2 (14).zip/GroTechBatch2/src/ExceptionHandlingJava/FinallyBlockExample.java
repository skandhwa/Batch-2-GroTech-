package ExceptionHandlingJava;

public class FinallyBlockExample {

	public static void main(String[] args) {
		
		///Connect with database
		
		try
		{
		int x=25/0;
		System.out.println(x);
		}
		
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Exception Caught" +e);
		}
		
		finally
		{
		
		System.out.println("I am code to close connection with database");
		
		}
		//
		System.out.println("The other pice of code");
		

	}

}
