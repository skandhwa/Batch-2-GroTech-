package ExceptionHandlingJava;

public class MultiCatchStatement {

	public static void main(String[] args) {
		
		try
		{
		
		int a[]=new int[5];
		a[7]=100;
		int x=10/0;
		
		System.out.println(x);
		System.out.println(a[7]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		
		
		
		int y=10;
		int z=y+20;
		System.out.println(z);

	}

}
