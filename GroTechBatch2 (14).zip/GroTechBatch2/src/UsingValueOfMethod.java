
public class UsingValueOfMethod {

	public static void main(String[] args) {
		
		int x=40;
		System.out.println(x+10);
		
	String str2=String.valueOf(x);
	System.out.println(str2+10);
	
	
		

	}

}
