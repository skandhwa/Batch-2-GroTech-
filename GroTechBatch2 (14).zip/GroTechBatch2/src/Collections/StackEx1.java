package Collections;

import java.util.Stack;

public class StackEx1 {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(34);
		stk.push(45);
		stk.push(14);
		stk.push(55);
		
		for(int x:stk)
		{
			System.out.println(x);
		}
		
		System.out.println("After deleting elements are");
		
		stk.pop();
		stk.pop();
		
		for(int y:stk)
		{
			System.out.println(y);
		}
		
		
		

	}

}
