package Collections;

import java.util.ArrayList;

public class ArrayListEx4 {

	public static void main(String[] args) {
		
		ArrayList <Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(34);
		li.add(56);
		
		li.clear();
		
	boolean flag=	li.isEmpty();
	
	System.out.println(flag);
		

	}

}
