package Collections;

import java.util.Vector;

public class VectorEx {

	public static void main(String[] args) {
		
		
		Vector<String> Vi=new Vector<String>();
		Vi.add("Rahul");
		Vi.add("Manish");
		Vi.add("Rohit");
		Vi.add("Mohit");
		
		for(String x:Vi)
		{
			System.out.println(x);
		}

	}

}
