package Collections;

import java.util.ArrayList;

public class ArrayListEx2 {

	public static void main(String[] args) {
		
ArrayList<Integer> li= new ArrayList<Integer>();
		
		li.add(12);
		li.add(34);
		li.add(45);
		li.add(56);
		
		li.add(4,50);
		for(int y:li)
		{
			System.out.println(y);
		}
		System.out.println();
		System.out.println("Printing Second Array List");
		
ArrayList<Integer> li2= new ArrayList<Integer>();
		
		li2.add(22);
		li2.add(94);
		li2.add(85);
		li2.add(76);
		for(int z:li2)
		{
			System.out.println(z);
		}
		
		
		li2.addAll(li);
		System.out.println();
		System.out.println("After Merging");
		
		for(int y:li2)
		{
			System.out.println(y);
		}
		System.out.println("Size of list 2 is :");
	int x=	li2.size();
	System.out.println(x);
	
	System.out.println("After Clearing the elements are:");
	
	li2.clear();
	for(int y:li2)
	{
		System.out.println(y);
	}
		
		
		

	}

}
