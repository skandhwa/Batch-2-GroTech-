package Collections;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayListEx7 {

	public static void main(String[] args) {
		
		String []lang= {"Java" ,"Python","C","C++"};
		
		for(String x:lang)
		{
			System.out.println(x);
		}
		
	//ArrayList<String> li2=new ArrayList<String>(Arrays.asList(lang));	
		
	ArrayList<String> li=	new ArrayList<String> (Arrays.asList(lang));
		
		
	for(String y:li)
	{
		System.out.println(y);
	}

	}

}
