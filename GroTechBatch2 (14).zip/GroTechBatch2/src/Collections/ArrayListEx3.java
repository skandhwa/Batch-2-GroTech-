package Collections;

import java.util.ArrayList;

public class ArrayListEx3 {

	public static void main(String[] args) {
		
		ArrayList <Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(34);
		li.add(56);
		
		System.out.println("Original Array list is");
		for(int x:li)
		{
			System.out.println(x);
		}
		
	boolean flag=	li.contains(83);
	System.out.println("The arrays list will return boolean value  "+flag);
	System.out.println();
		
	
	int x=li.get(2);
	System.out.println(x);
		
		
		
		ArrayList<Integer> li2=(ArrayList<Integer>)li.clone();
		System.out.println("Cloned Array list is");
		for(int y:li2)
		{
			System.out.println(y);
		}
		
		
		

	}

}
