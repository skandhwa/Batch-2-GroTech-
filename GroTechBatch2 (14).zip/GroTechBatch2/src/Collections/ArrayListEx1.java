package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListEx1 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li= new ArrayList<Integer>();
		
		li.add(12);
		li.add(34);
		li.add(45);
		li.add(56);
		
		///First way of traversing through an array list
		System.out.println(li);
		
		
		///Second way of traversing array list
		System.out.println();
		System.out.println("Seond way of Traversing");
		
		
		Iterator it=li.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		System.out.println();
		System.out.println("Third way of Traversing");
		
		//Third way of Traversing through array List
		for(int x:li)
		{
			System.out.println(x);
		}
		
		for(int i=0;i<li.size();i++)
		{
			System.out.println(i);
		}
		
		
		
		
		
		

	}

}
