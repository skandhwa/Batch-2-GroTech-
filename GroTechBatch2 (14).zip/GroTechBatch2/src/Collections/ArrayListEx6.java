package Collections;

import java.util.ArrayList;

public class ArrayListEx6 {

	public static void main(String[] args) {
		
		ArrayList <Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(34);
		li.add(56);
		
		for(int y:li)
		{
			System.out.println(y);
		}
		
		Integer []a=new Integer[li.size()];
		
		a=li.toArray(a);
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		

	}

}
