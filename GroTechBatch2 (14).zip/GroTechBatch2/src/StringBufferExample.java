
public class StringBufferExample {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Saurabh");
		sb.append("Kandhway");
		System.out.println(sb);
		
		sb.insert(1,"Java");
		System.out.println(sb);
		
	}

}
