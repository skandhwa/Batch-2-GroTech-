
public class StringReverse {

	public static void main(String[] args) {
		
		String str="madam";
		char []str1=str.toCharArray();
		
		for(int i=str1.length -1 ;i>=0;i--)//i=4,4>=0
		{
			System.out.print(str1[i]);
		}
		System.out.println();
		
		if(str.equals(str1))
		{
			System.out.println("String is Palindrome");
		}
		else
			System.out.println("String is not Palindrome");
		
		
		

	}

}
