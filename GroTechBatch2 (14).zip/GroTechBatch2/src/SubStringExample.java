
public class SubStringExample {

	public static void main(String[] args) {
		
//		String str1="Football  ";
//	
//		String str2=str1.substring(5);
//		
//		System.out.println(str2);
//		
		
		String str2="Basketball";
		String str3=str2.substring(1,2);
		
		System.out.println(str3);
		
		

	}

}
