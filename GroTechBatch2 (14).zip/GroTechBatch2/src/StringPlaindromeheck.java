
public class StringPlaindromeheck {

	public static void main(String[] args) {
		
		String str="radar";
		String revString="";
	int x=	str.length();//5
	
	for(int i=x-1;i>=0;--i)///i=4,4>=0//i=3,3>=0
	{
		revString=revString+str.charAt(i);//""+str.charAt(4)//ai
	}
	
	System.out.println(revString);
	
	if(str.toLowerCase().equals(revString.toLowerCase()))
	{
		System.out.println("Palindrome String");
	}
	else
	{
		System.out.println("Not Palindrome String");
	}
	
	
		
		

	}

}
