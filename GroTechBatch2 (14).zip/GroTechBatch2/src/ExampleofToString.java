class Employee6
{
	int id;
	String name;
	String location;

Employee6(int id,String name,String location)
{
	this.id=id;
	this.name=name;
	this.location=location;
}
	
}
public class ExampleofToString {

	public static void main(String[] args) {
		
		Employee6 obj= new Employee6(100,"Saurabh","Kolkata");
		Employee6 obj2= new Employee6(102,"Gaurabh","Delhi");
		System.out.println(obj);
		System.out.println(obj2);
		
		
		
		

	}

}
