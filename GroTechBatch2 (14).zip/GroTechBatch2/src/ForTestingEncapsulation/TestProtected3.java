package ForTestingEncapsulation;

import Batch2GroTech.TestProtected1;

public class TestProtected3 extends TestProtected1 {

	public static void main(String[] args) {
		
		CF obj4=new CF();
		obj4.msg();

	}

}
