package ForTestingEncapsulation;

import Batch2GroTech.PublicExample1;

public class PublicExample3 {

	public static void main(String[] args) {
		
		PublicExample1 obj=new PublicExample1();
		obj.display();
		

	}

}
