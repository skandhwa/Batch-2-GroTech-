
public class StringExamples5 {

	public static void main(String[] args) {
		
		String str1="India";
		String str2="inDiA";
		String str3="";
		
	boolean flag=	str1.equals(str2);
	System.out.println(flag);
	
	boolean flag2=str1.equalsIgnoreCase(str2);
	System.out.println(flag2);
	
	
	boolean flag3=str3.isEmpty();
	System.out.println(flag3);
	
	
	String str4="India";
String str5=	str4.concat("WestIndies");
	
	System.out.println(str5);
		
		

	}

}
