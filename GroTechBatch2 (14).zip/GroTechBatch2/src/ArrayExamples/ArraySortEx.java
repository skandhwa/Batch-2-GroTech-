package ArrayExamples;

import java.util.Arrays;

public class ArraySortEx {

	public static void main(String[] args) {
		
		int a[]= {22,12,45,67};
		Arrays.sort(a);
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		

	}

}
