package ArrayExamples;

public class SortingArray {

	public static void main(String[] args) {
		
		int a[]=new int[] {23,12,45,6,15,8};
		
		
		

	}

}
