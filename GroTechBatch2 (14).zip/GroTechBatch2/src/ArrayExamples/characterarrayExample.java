package ArrayExamples;

public class characterarrayExample {

	public static void main(String[] args) {
		
		char []a= {'a','b','c','d'};
		
		for(char c:a)
		{
			System.out.println(c);
		}

	}

}
